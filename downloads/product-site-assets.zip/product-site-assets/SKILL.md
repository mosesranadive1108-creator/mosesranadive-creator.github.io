---
name: product-site-assets
description: Generates and processes every asset for a 3D product scroll site with Higgsfield - hero product reference image, 3D model (GLB), exploded view, assembly video, transparent frame sequence, card image, accessory shots - with a strict cost-quote-and-approve gate before every generation and a mandatory 3D feasibility test. Used by product-site-builder (phase 3 and 4); also use when asked to make a product's assembly animation, an image-to-3D model for a web page, or a transparent frame sequence from a video.
---

# Product site assets (Higgsfield pipeline)

Runs inside `product-site-builder` (Phases 3 and 4). Its hard rules apply here too. Scripts live in `../product-site-builder/scripts/`. Commands, prompts and cost notes are in `references/higgsfield-recipes.md`.

## The cost gate (before EVERY generation)
1. Get the real price: `higgsfield generate cost <model> <same flags you will use>`. Prices change; never quote from memory.
2. Tell the user, in one short message: what it makes, the model, the key settings, the cost, **credits spent so far, and the remaining budget**.
3. Ask for a yes (`AskUserQuestion`: approve / change / skip). A yes covers only what you quoted. If you need a retry, quote it again.
4. Run it. Show the result (open the image; for 3D, render it) and ask whether it is good enough **before** spending on the next step that builds on it.
5. Log it in `BUILD_LOG.md`: item, model, quoted, actual, user's words.

Batch approval is allowed only when you list every item with its cost and a total, and the user approves that exact list.

If a job is refused (`"Pro" or "Ultimate" plan required`, rate limit), nothing was charged: say so, offer the next-best model, and re-quote.

## Step 0: Check the plan
`higgsfield account status`, then `higgsfield model get <model>` for the params of each model you plan to use. Check which models the plan allows by trying the cost command (gated models fail there or at create time). Do this before promising the user any model.

## Step 1: Hero reference image  (about 1 to 3 credits)
One square, plain-background, three-quarter view of the product, premium catalogue photography, fully inside the frame. Make 2 variants, show both, let the user choose. Use a **text-only prompt** for a new scene; give reference images only when a model is meant to follow them (see recipes). Design the product's look here: it becomes the 3D model, so material and detail choices matter.

## Step 2: Is a good 3D model possible? (mandatory test)

### 2a. Rubric (before spending on 3D)
| Likely good for 3D | Likely poor for 3D |
|---|---|
| Rigid hardware with a clear silhouette: headphones, speakers, bottles, shoes, watches, cameras, tools | Transparent or glass, chrome mirrors, jewellery |
| One dominant material, bold shapes | Thin wires, mesh, lace, hair, fur, plants |
| | Soft, floppy or foldable items (apparel, bags), liquids, food |
| | Text-heavy or tiny-detail surfaces, scenes with several objects |

If the rubric says "poor", tell the user before spending anything and let them decide whether to test anyway.

### 2b. Test generation
Quote and run image-to-3D from the chosen reference (see recipes: single mesh, PBR textures). Then **inspect it for real**: put the GLB into the template (`public/models/product.glb`), view it in the browser pane at hero size and card size, rotate through the rest pose.

PASS only if all hold: clean silhouette, no holes, spikes or melted parts, textures read at card size, one mesh, file under about 3 MB after `optimize-glb.sh`. One retry is allowed (a different model or settings), re-quoted.

### 2c. If it fails: stop and tell the user
Say plainly what is wrong (show the render), what was spent, and offer: (1) supply their own GLB or better product photos for one more try, (2) choose a different hero product, (3) end the build. Do not ship a rough model and do not switch to another technique unasked. Continue only on their answer.

## Step 3: The "end render" (the rest pose)
The pixel-exact image the hero sequence ends on and the product takes over from. It must be a **transparent, square** image of the product at its rest pose.
A render of the actual GLB at the rest pose. This needs the running site, so **scaffold the project now** (`scaffold.sh`; ask before `npm install`), put the model at `public/models/product.glb`, run the dev site, set `hero.restRotation` with the user, then use `window.__snapshot('[data-hero-anchor]', 1024)` with `scripts/snap-receiver.py` to save it (full steps in `product-site-effects` section 4). Because it is a render of the model, the hand-off to 3D is invisible. Do this **before** Step 4 and Step 5.

## Step 4: Exploded view  (about 1 to 3 credits)
Take the end render composited on a flat light-grey (`#d9dce1`) and make an exploded-parts image of the same product: same camera angle, scale, materials and lighting, parts pulled apart along their natural axes and floating, every part inside the frame, flat grey background, no text. This is the video's first frame. Show it; the parts must plausibly belong to the product.

## Step 5: Assembly video  (the largest cost; quote carefully)
Image-to-video with a **start frame (exploded)** and **end frame (end render on the same flat grey)**: the parts glide in and click into place while the view turns into the rest pose, camera locked off, background flat and constant, no extra objects, 5 seconds, 1:1, no audio. Pick the model the plan allows and `higgsfield model get` for its start/end-frame params. See recipes for prompts. Check the result frame by frame (a contact sheet) before processing: parts must really assemble, the last frame must match the end render.

## Step 6: Frame sequence (free)
`bash ../product-site-builder/scripts/make-sequence.sh <video.mp4> <end-render.png> <out-dir> 96 960 88`: keys out the flat grey (auto-sampled), de-fringes edges, resamples to exactly N frames, blends only the last 3 frames into the end render, exports WebP. It fails if the frame count is wrong. Typical size: 4 to 6 MB. Preview two frames on a dark background.

## Step 7: Card image and accessory shots
- **Hero card image:** a render of the model at the card pose (`__snapshot('[data-dock]', 1000)` with `window.__noHandoff = true`).
- **Accessories** (about 1.5 credits each at 1K): one per card, **text-only** prompts that restate the brand's materials and a shared studio style (seamless deep-navy or brand-tone background, soft top spotlight, floor reflection, no props). Generate in parallel at most 4 at a time (the account limit), show them together, redo only the weak ones.

## Step 8: Specs drawing (optional)
A transparent line drawing for the spec section background. If the user provides one, use it. Otherwise it can come from the exploded view; ask first, since it costs credits.

## Step 9: Optimise and place
`scripts/optimize-glb.sh` for the model; WebP for images; place under `public/` with the names in `template/public/ASSETS.md`. Run `node ../product-site-builder/scripts/check-site.mjs <project>`.

## Mistakes that already cost credits (do not repeat)
- **Download the job's `result_url` from the JSON**, never the first URL in the output: with reference-image jobs the input image's URL comes first, which makes a good result look like a copy.
- Re-quote before any retry, even of "the same thing".
- Do not run more than 4 jobs at once (the account limit); the rest are refused, uncharged.
- A model refusing because of the plan is free information: change model, do not upgrade the user's plan for them.
