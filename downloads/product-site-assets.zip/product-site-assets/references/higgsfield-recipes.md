# Higgsfield recipes

Verify models and parameters on the user's account first (`higgsfield model list`, `higgsfield model get <model>`). Names, prices and plan access change. The numbers below are what was observed while building the MOZIT headphone site (basic plan) and are **examples only**: always re-quote with `higgsfield generate cost`.

Add `--wait --json` to `create` so the call blocks and returns a result you can parse. Save raw outputs and the prompts in the project's `assets-raw/`.

## Parse the result safely
```bash
higgsfield generate create <model> ... --wait --json > job.json
python3 -c "import json;d=json.load(open('job.json'));d=d[0] if isinstance(d,list) else d;print(d['status'], d['result_url'])"
curl -sL -o out.png "$(python3 -c "import json;d=json.load(open('job.json'));d=d[0] if isinstance(d,list) else d;print(d['result_url'])")"
```

## Quote
```bash
higgsfield generate cost gpt_image_2_5 --prompt "..." --quality high --resolution 1k --aspect_ratio 1:1
```

## Images
| Task | Model (seen) | Notes |
|---|---|---|
| Hero reference, accessories, specs art | `gpt_image_2_5` | Flags: `--quality low|medium|high|xhigh|max`, `--resolution 1k|2k|4k`, `--aspect_ratio`, `--background auto|opaque|transparent`. High 1K ≈ 1.5 credits, high 2K ≈ 2.75. Use `--background transparent` for cutouts |
| Reference-driven scenes (product in a new setting) | `nano_banana_pro` (≈ 2 credits) or `seedream_v5_pro` | Pass the product with `--image <file>` |
| Cut out a background | `image_background_remover` (≈ 1 credit) | Exactly one image |

Prompt pattern for a hero reference (text only):
> Studio product render of <product>, <brand> in small embossed lettering. <materials and colours>. Three-quarter front view, whole product fully visible and centred with generous margin. Plain seamless light grey background, soft even studio lighting, crisp detail, photorealistic, no other text, no props.

Prompt pattern for an accessory shot (text only, shared style):
> Product photo of <name>: <one-line description>. Brand design language: <materials, accent light>. Single product, centred with margin, three-quarter view, seamless deep navy background with a soft top spotlight and subtle floor reflection, premium catalogue photography, photorealistic, no other text, no props.

## Image to 3D
| Model (seen) | Flags | Cost seen |
|---|---|---|
| `hunyuan3d_v3_image_to_3d` | `--image <file> --enable_pbr true --face_count 150000` | ≈ 11 basic, ≈ 19 with PBR at 150k faces |
| `tripo_h3_1_image_to_3d` | `--image <file>` | ≈ 9 |
| `meshy_v7_image_to_3d`, `multi_image_to_3d` | `--image <file>` (`--should_texture true` for the latter) | cost estimator may not support them: ask before running unquoted jobs |

Download the GLB from `result_url`. Optimise: `scripts/optimize-glb.sh in.glb out.glb` (a 23 MB result became 0.5 MB). The template expects **one mesh**; if there are several, run `npx @gltf-transform/cli@4 join out.glb out.glb`.

## Assembly video (start + end frames)
| Model (seen) | Flags | Notes |
|---|---|---|
| `kling3_0` | `--start-image <exploded.png> --end-image <end-on-grey.png> --aspect_ratio 1:1 --duration 5 --mode std --sound off` | std ≈ 6.25 credits. `--mode pro` needs a Pro plan |
| `seedance_2_5` | `--mode omni_reference --start-image ... --end-image ... --duration 5 --resolution 720p --generate_audio false` | ≈ 35 credits; needs a Pro plan on the basic account used here |
| `seedance_2_0` | start/end images; `--mode std|fast` | ≈ 22.5 credits |

Video prompt pattern:
> Premium product assembly animation. Start from the exploded view: every component of the <product> glides smoothly inward along its axis and clicks precisely into place (<name the parts: screws drop in, drivers seat into the cups, covers close, cushions press on...>). While assembling, the product rotates gently from the front view into the final three-quarter view of the end frame. Smooth eased mechanical motion with a soft settle at the end, finishing exactly on the end frame and holding still. Locked-off static camera, no camera movement, no zoom. Plain flat light grey seamless background that stays perfectly constant, soft even studio lighting, no extra objects, no text, photorealistic.

Quality note: the video is usually about 960 px square. If the first frames look soft at the 1.3× zoom the hero uses, a video upscale (for example `bytedance_video_upscale`, about 2 credits) is the cheap fix; quote it, let the user decide.

## Exploded-view prompt (image, from the end render composited on `#d9dce1`)
> Exploded-view product render of these exact <product> from the reference image, keeping the identical camera angle, orientation, scale, materials and lighting. The components are pulled apart evenly along their natural assembly axes and float in mid-air: <list the main parts, the screws and a thin cable>. Clean, precise, technical, symmetric layout, every part fully inside the frame with margin. Plain flat seamless light grey background (#d9dce1), soft even studio lighting, photorealistic, no text, no labels, no shadows on the background.

(Pass the grey-composited end render with `--image`. Composite with: `ffmpeg -f lavfi -i color=c=0xd9dce1:s=1024x1024 -i end.png -filter_complex "[0][1]overlay=0:0:format=auto" -frames:v 1 end-grey.png`.)

## Errors you will meet
- `Error: "Pro" or "Ultimate" plan required`: model is plan-gated; no charge; pick another model.
- `rate_limit_reached ... concurrent_jobs_limit`: too many jobs at once; no charge; wait and retry fewer.
- `Unsupported validation rules for <model>` from `cost`: that model's price can't be estimated; ask the user before running it.
- `Missing required params: prompt`, or a flag that "needs a value": check each flag is separate (`--quality high --resolution 2k`) when scripting.
