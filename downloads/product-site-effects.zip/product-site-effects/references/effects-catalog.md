# File map of the template

| Area | Files | Notes |
|---|---|---|
| Config | `site.config.json`, `src/config/site.ts` | Single source of truth; `site.ts` is only a typed view |
| Theme/fonts | `src/anim/theme.ts`, `src/styles/tokens.css`, `index.html` + `vite.config.ts` | Theme sets CSS variables at startup; the Vite plugin fills title, description and the font link |
| Page ambience | `src/anim/ambience.ts` | Page background easing, `layout.fit`, `ambience.glow`; independent of three.js |
| Shared state | `src/anim/state.ts` | `scroll` progress (assemble, handoff, rise, specs, fly), `pointer`, `layout`, `ambience`, reduced motion; dev handle `window.__scroll` |
| Scroll wiring | `src/anim/scroll.ts` | Lenis + ScrollTrigger; hero beats from the config; spec reveal; hero fades |
| DOM to world | `src/anim/dock.ts` | Projects a DOM box into the 3D scene (the product fits the hero box and the card) |
| Pointer UI | `src/anim/surface.ts` | Cursor highlight on `.glass` elements |
| Hero | `src/sections/Hero.tsx`, `AssemblySequence.tsx`, `blueprintShader.ts` | Pinned stage; WebGL frame player with blueprint-to-real shader |
| 3D | `src/scene/Stage.tsx`, `Product3D.tsx`, `particles.ts`, `constants.ts` | Lights and camera; model flight; hover dissolve; dev `__snapshot` |
| Specs | `src/sections/Specs.tsx`, `SpecsArt.tsx` | Glass cards with ghost numerals; optional shader-drawn art |
| Lineup + cart | `src/sections/Products.tsx`, `src/cart/*` | Horizontal card rail; localStorage cart; drawer |
| Footer | `src/sections/Footer.tsx`, `NoteWord.tsx`, `ParticleField.tsx` | Particle product, wordmark that sheds notes |
| Background | `src/sections/BgMotion.tsx` | Mesh gradient + perspective grid, colours from `theme.mesh` |
| Cursor | `src/sections/CursorTrail.tsx` | WebGL ribbon trail |
| Logo | `src/sections/Logo.tsx`, `public/favicon.svg` | Mark (headphone, monogram, none) + wordmark; regenerate the favicon from the mark |
| Styles | `src/styles/app.css` | All layout and components; look for the section comments |

## Adding a new section
1. Component in `src/sections/`, copy from the config (add its fields to `site.config.json` and the type in `site.ts`).
2. Add it in `App.tsx` between the existing sections.
3. If it needs scroll progress, add a `ScrollTrigger` in `scroll.ts` writing to `scroll.<name>`.
4. Style with the theme variables, not hex values. Add a reduced-motion rule if it animates.

## Performance budget
Hero sequence ≤ about 6 MB, model ≤ 3 MB, accessory images ≤ 100 KB each (WebP), JS main chunk about 135 KB gzip (three.js is a lazy chunk). Background shader renders below device resolution on purpose. All animation loops pause when off screen.
