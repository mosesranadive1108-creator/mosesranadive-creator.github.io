# Gotchas (each one cost real time on the first build)

## Clicks and pointer events
- **react-three-fiber forces `pointer-events: auto` on its canvas wrapper**, overriding a `pointer-events: none` parent. The canvas then swallows every click on the page beneath. Fix (already in the template): `.stage, .stage * { pointer-events: none !important }`. If buttons "don't respond" to real clicks but a scripted `.click()` works, run `document.elementFromPoint(x, y)` and see what sits on top.
- Overlay canvases (cursor trail, spark/note layer, footer particles) must be `pointer-events: none` unless they own the interaction; parents listen for `pointermove` instead.

## WebGL and React
- React StrictMode runs effects twice in dev. **Do not call `loseContext()` in a WebGL effect cleanup**: the second run then gets a dead context and the canvas silently goes black. Delete the program and buffers only.
- Never call `canvas.getContext('webgl')` on react-three-fiber's canvas (for debugging): it creates a context of the wrong type and breaks the scene.
- Do not request `powerPreference: 'low-power'` for a background shader: it can fail to create a context on some machines.
- Dev servers can end up with two copies of a shared module after you edit it (state that "does not update"). Restart the dev server when behaviour contradicts the code.

## GLSL
- Variable names can clash across a long `main()` (`float w` then `vec2 w`): compile error `redefinition`, black canvas.
- `smoothstep(edge0, edge1, x)` is undefined if `edge0 >= edge1`: write `1.0 - smoothstep(a, b, x)` instead of reversed edges.
- **Read console messages unfiltered.** A pattern filter hides shader compile errors.
- Additive blending multiplies alpha twice if you premultiply in the shader: output colour and alpha separately.
- On a transparent canvas keep each pixel's brightest colour and accumulate alpha; adding colour and alpha together makes lone particles dim.

## Scroll and animation
- Wire Lenis into GSAP: `lenis.on('scroll', ScrollTrigger.update)` and drive `lenis.raf` from `gsap.ticker`, with `lagSmoothing(0)`.
- Wrap ScrollTrigger and tween setup in `gsap.context(...)` and `ctx.revert()` on cleanup, or StrictMode remounts leave elements stuck at opacity 0.
- Use `invalidateOnRefresh: true` with function-based starts (`top+=${innerHeight * n}`).
- Make physics frame-rate independent (`step = dt * 60`): a slow machine otherwise takes forever to settle.
- Expose a dev handle (`window.__lenis`, `window.__scroll`) to test: `__lenis.scrollTo(px, {immediate: true})`. A real wheel scroll test is still needed once.
- Drawers need `data-lenis-prevent` so their content can scroll under Lenis.

## Layout traps
- `.glass` (position: relative) later in the stylesheet overrides `position: absolute` on an element that also has the class: raise specificity (`.cart .cart__panel`).
- Avoid duplicate CSS blocks: later wins, and old copies hide new edits. Search for the selector before editing.
- Fixed canvas layers that take `rect` measurements: measure while the hero is pinned and cache, or the product chases the section off screen.
- Mobile: scale compositions with `layout.fit` (aspect-based), keep hero copy at the top and the product below.

## Assets
- `ffmpeg` builds often lack libwebp: export WebP with `sharp-cli`.
- Colour-keying leaves a coloured halo: premultiply by alpha squared (see `make-sequence.sh`).
- Blend only the last 3 frames into the end render; blending earlier ghosts moving parts.
- White CTA text on a light neon fails contrast: use dark text.
- A GLB straight from an image-to-3D tool can be 20+ MB: Draco plus WebP textures brought one to 0.5 MB.

## Testing in the browser pane
- A preview often runs at about 3 fps. Wait several seconds after a jump before judging animation, and never judge damped motion from one early screenshot.
- Screenshots right after a click can be stale: wait, then capture again.
- Use a fresh `?r=<n>` query to force a clean reload.
- `read_page` / `find` coordinates go stale while Lenis is still moving: wait for the page to settle before clicking by coordinates.
