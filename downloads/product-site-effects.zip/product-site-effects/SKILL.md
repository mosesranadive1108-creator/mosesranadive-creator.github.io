---
name: product-site-effects
description: Customises and tunes the product-site template - theme and copy from site.config.json, effect switches, hero scroll timing, 3D rest pose and card-image baking, blueprint shader, mesh-gradient background, cursor trail, liquid-glass cards, particle footer, music-note wordmark, cart. Used by product-site-builder (phase 5); also use when asked to adjust, add, remove or debug any scroll, glass, particle, background or cursor effect on a site built from this template.
---

# Product site effects

Everything is driven by `site.config.json` in the project. Change the JSON first; edit code only for things the config doesn't cover. Preview in the browser pane after **every** change and report what you actually saw. Known traps are in `references/gotchas.md`: read it before debugging. A file-by-file map is in `references/effects-catalog.md`.

## 1. Theme and copy (config only)
- `theme.colors.*` become CSS variables at startup (`src/anim/theme.ts`): `abyss` (page), `frost` (text), `fog`/`mist` (secondary text), `sky` (links, accents), `neon` (CTA fill), `azure*` (tints). `theme.ctaText` is the CTA label colour: the pair must reach 4.5:1 (`check-site.mjs` tests it). A light CTA needs dark text.
- `theme.heroBg` and `theme.darkBg`: the page tone eases from one to the other as the product rises.
- `theme.mesh`: six colours for the mesh-gradient background nodes. `theme.noteColors`: the wordmark's note colours.
- `fonts`: heading and body (Google Fonts); `googleQuery` is the CSS2 query string for the `<link>`.
- All copy lives in `hero`, `specs`, `lineup`, `products`, `footer`, `cart`, `nav`, `brand`, `meta`.

## 2. Effect switches (`effects` in the config)
| Switch | Controls |
|---|---|
| `meshBackground` | Animated mesh-gradient WebGL background (`BgMotion.tsx`) |
| `cursorTrail` | Glowing trail after the cursor (`CursorTrail.tsx`); fine pointers only |
| `cursorParticles` | Cursor dissolves the 3D model into particles |
| `noteWordmark` | Footer wordmark sheds notes when the cursor crosses it |
| `footerParticles` | Particle product in the footer (also set `footer.particles`: `headphone` preset, `image` = sampled from `assets.cutout`, or `none`) |
| `cart` | Cart button and drawer. Off: product buttons become links (`products[].href`) |

Reduced-motion users get stills automatically; touch screens skip cursor effects.

## 3. Hero scroll beats
`hero.beats` are in viewport heights of scroll while the hero is pinned (hero height is 220svh in `app.css`):
- `assembled`: sequence finishes (default 0.95)
- `handoffStart` / `handoffEnd`: cross-fade to the 3D product (0.92 to 1.02; starting just before the sequence ends, with no pause, avoids a "dead" extra scroll)

If the user says "I have to scroll once more before it turns 3D", pull `handoffStart` and `assembled` earlier so the fade overlaps the last frames. The last 3 frames already match the end render, so overlap is invisible.

## 4. 3D pose, end render, card image
Order matters: **choose the rest pose and bake the end render BEFORE generating the exploded view and the video**, because the video ends on that render.
1. Put the optimised GLB at `public/models/product.glb`, run the dev site.
2. Tune `hero.restRotation` `[rx, ry, rz]` (radians) so the product shows its best three-quarter view. In the browser console `window.__showRest = true` forces the model visible at rest (dev flag), `window.__noHandoff = true` keeps it visible when docked.
3. Bake the end render: `python3 scripts/snap-receiver.py end.png` in a terminal, then in the browser console: `const u = __snapshot('[data-hero-anchor]', 1024); await fetch('http://127.0.0.1:5199/save',{method:'POST',headers:{'content-type':'text/plain'},body:u})`. The PNG is transparent, square, at the exact framing the site uses.
4. After the sequence is in place, bake the card image the same way from `'[data-dock]'` (scroll so the model sits in the card first, with `window.__noHandoff = true`), convert to WebP, save as `assets.cardImage`.
5. Fit is automatic: `Product3D.tsx` measures the model's own bounding box at the rest rotation, so no hard-coded sizes.
6. The hover dissolve needs a **single-mesh** GLB. With several meshes it is skipped; join them first (`gltf-transform join`).

## 5. Blueprint look
`blueprintShader.ts` traces edges (outline plus internal detail), adds hatching, a drafting grid and a scan line, and dissolves into the real image as the last parts click in (`AssemblySequence.tsx`: `real` ramps over the final third). Knobs: line colour (`lineCol`, `inkCol`), grid density (`vUv * 24.0` and `* 6.0`), when it turns real (`(p - 0.6) / 0.33`). The same shader draws the optional specs drawing (`SpecsArt.tsx`, set `assets.specsArt` to `null` to remove).

## 6. Other effects
- **Mesh background:** six drifting colour nodes from `theme.mesh`, domain-warped by noise, plus a perspective wire grid and vignette. Keep it darker than the content; check text contrast over its brightest area.
- **Liquid glass** (`.glass` in `app.css`): blur plus saturation, a gradient rim and a cursor-following highlight (`anim/surface.ts`). Rim strength is the `border` / `box-shadow inset` / `::before` gradient alphas.
- **Spec cards:** glass cards with a giant outlined numeral from `specs.items[].ghost`.
- **Footer wordmark:** drawn on a canvas so the cursor can strike notes off the exact letters. The note shapes are audio-themed: for other products change `buildSprites` in `NoteWord.tsx` (sparkles, leaves, stars...).
- **Particle product:** `ParticleField.tsx`: the `headphone` preset, or any product sampled from its cutout (silhouette and edges weighted).
- **Cart:** front-end only, saved in `localStorage` under `cart.storageKey`. The Checkout button does nothing: say so, and never present it as a working payment.

## 7. Quality rules while tuning
- One accent per view; text always at 4.5:1; CTA text colour from the config, never hard-coded.
- Never give an overlay layer pointer events (`.stage` must stay click-through).
- Sections of copy stay short; remove any claim the user didn't supply.
- After any change: `npx tsc -b`, `npm run build`, then look at the page.
