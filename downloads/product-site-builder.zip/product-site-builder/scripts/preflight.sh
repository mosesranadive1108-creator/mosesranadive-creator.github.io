#!/usr/bin/env bash
# Read-only preflight. Reports what is installed and what is missing. Installs and changes NOTHING.
# Usage: bash preflight.sh
ok()   { printf "  [ok]       %s\n" "$1"; }
miss() { printf "  [MISSING]  %s\n" "$1"; }
warn() { printf "  [check]    %s\n" "$1"; }

echo "Toolchain"
if command -v node >/dev/null; then
  v=$(node -v); major=${v#v}; major=${major%%.*}
  if [ "$major" -ge 20 ]; then ok "node $v"; else warn "node $v (need 20 or newer)"; fi
else miss "node (install Node 20+)"; fi
command -v npm >/dev/null && ok "npm $(npm -v)" || miss "npm"
prefix=$(npm config get prefix 2>/dev/null)
if [ -n "$prefix" ] && [ -w "$prefix" ]; then ok "npm global prefix writable ($prefix)"
else warn "npm global prefix not writable ($prefix): global installs will fail. Ask the user before changing it (the fix is a user-level prefix such as ~/.npm-global plus a PATH entry)."; fi
if [ -n "$(find "$HOME/.npm" -maxdepth 4 -user root 2>/dev/null | head -1)" ]; then warn "~/.npm contains root-owned files. The helper scripts use a private cache automatically; for plain npm commands pass --cache <dir>. Do NOT run sudo chown without asking the user."; else ok "npm cache writable"; fi
command -v ffmpeg  >/dev/null && ok "ffmpeg"  || miss "ffmpeg (needed to turn video into frames)"
command -v ffprobe >/dev/null && ok "ffprobe" || miss "ffprobe"
command -v python3 >/dev/null && ok "python3" || miss "python3"
command -v git     >/dev/null && ok "git"     || miss "git (needed to fetch skill repos)"

echo
echo "Higgsfield"
HF=$(command -v higgsfield || ls "$HOME/.npm-global/bin/higgsfield" 2>/dev/null | head -1)
if [ -n "$HF" ]; then
  ok "higgsfield CLI at $HF ($("$HF" --version 2>/dev/null | head -1))"
  status=$("$HF" account status 2>&1 | sed -E 's/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+/<email hidden>/')
  case "$status" in
    *credits*) ok "signed in: $status" ;;
    *) warn "not signed in or no workspace selected: $status" ;;
  esac
else miss "higgsfield CLI (npm i -g @higgsfield/cli, then: higgsfield auth login)"; fi

echo
echo "Skills present in ~/.claude/skills"
for s in higgsfield-generate higgsfield-product-photoshoot taste-skill gpt-tasteskill soft-skill frontend-design; do
  [ -d "$HOME/.claude/skills/$s" ] && ok "$s" || miss "$s"
done

echo
echo "Done. Nothing was installed or changed."
