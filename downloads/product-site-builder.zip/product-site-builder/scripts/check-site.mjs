#!/usr/bin/env node
// Validates a site project against site.config.json. Exit code 1 if anything blocking fails.
// Usage: node check-site.mjs <project-dir> [--placeholder "OldBrand"]
//   checks: required fields, every asset file exists, model size, frame count matches, colour contrast
//   (CTA text on CTA colour, body text on page colour), and no leftover placeholder brand text in src/.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'

const dir = resolve(process.argv[2] ?? '.')
const phIdx = process.argv.indexOf('--placeholder')
const placeholder = phIdx > -1 ? process.argv[phIdx + 1] : null
let fails = 0
const pass = (m) => console.log(`  [ok]    ${m}`)
const fail = (m) => (fails++, console.log(`  [FAIL]  ${m}`))
const note = (m) => console.log(`  [note]  ${m}`)

const cfgPath = join(dir, 'site.config.json')
if (!existsSync(cfgPath)) {
  console.log(`No site.config.json in ${dir}`)
  process.exit(1)
}
const c = JSON.parse(readFileSync(cfgPath, 'utf8'))

console.log('Config')
const need = ['brand.name', 'brand.slug', 'meta.title', 'meta.description', 'hero.titleLines', 'hero.frameCount', 'specs.items', 'products', 'assets.model', 'assets.cardImage', 'assets.cutout', 'theme.colors.neon', 'theme.ctaText']
for (const k of need) {
  const v = k.split('.').reduce((o, p) => (o == null ? o : o[p]), c)
  v == null || v === '' || (Array.isArray(v) && v.length === 0) ? fail(`missing ${k}`) : pass(k)
}
if (c.products?.filter((p) => p.featured).length !== 1) fail('exactly one product must have "featured": true')

console.log('\nAssets')
const pub = (p) => join(dir, 'public', p.replace(/^\//, ''))
const must = (p, label) => (existsSync(pub(p)) ? pass(`${label}: ${p}`) : fail(`${label} not found: public${p}`))
must(c.assets.model, 'model')
if (existsSync(pub(c.assets.model))) {
  const mb = statSync(pub(c.assets.model)).size / 1048576
  mb > 3 ? fail(`model is ${mb.toFixed(1)} MB (target under 3 MB: run optimize-glb.sh)`) : pass(`model size ${mb.toFixed(2)} MB`)
}
must(c.assets.cardImage, 'card image')
must(c.assets.cutout, 'cutout')
if (c.assets.specsArt) must(c.assets.specsArt, 'specs art')
for (const p of c.products ?? []) p.image ? must(p.image, `product ${p.id}`) : fail(`product ${p.id} has no image`)
const seqDir = pub(c.hero.framesPath)
if (existsSync(seqDir)) {
  const n = readdirSync(seqDir).filter((f) => f.endsWith('.webp')).length
  n === c.hero.frameCount ? pass(`${n} sequence frames`) : fail(`frame count: ${n} files but hero.frameCount is ${c.hero.frameCount}`)
  let total = 0
  for (const f of readdirSync(seqDir)) total += statSync(join(seqDir, f)).size
  total / 1048576 > 8 ? note(`sequence is ${(total / 1048576).toFixed(1)} MB (consider smaller frames or lower quality)`) : pass(`sequence ${(total / 1048576).toFixed(1)} MB`)
} else fail(`sequence folder not found: public${c.hero.framesPath}`)

console.log('\nContrast (WCAG: text needs 4.5)')
const lum = (hex) => {
  const n = parseInt(hex.replace('#', ''), 16)
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => {
    v /= 255
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4
  })
  return 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2]
}
const ratio = (a, b) => {
  const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p)
  return (x + 0.05) / (y + 0.05)
}
const col = c.theme.colors
const pairs = [
  ['CTA text on CTA colour', c.theme.ctaText, col.neon],
  ['CTA text on CTA hover colour', c.theme.ctaText, col.neonHover],
  ['body text (frost) on page (abyss)', col.frost, col.abyss],
  ['secondary text (fog) on page', col.fog, col.abyss],
  ['muted text (mist) on page', col.mist, col.abyss],
  ['links (sky) on page', col.sky, col.abyss],
]
for (const [label, fg, bg] of pairs) {
  if (!fg || !bg) continue
  const r = ratio(fg, bg)
  r >= 4.5 ? pass(`${label}: ${r.toFixed(1)}`) : fail(`${label}: ${r.toFixed(1)} (needs 4.5)`)
}

if (placeholder) {
  console.log(`\nLeftover placeholder text ("${placeholder}")`)
  const hits = []
  const walk = (d) => {
    for (const f of readdirSync(d)) {
      const p = join(d, f)
      if (statSync(p).isDirectory()) walk(p)
      else if (/\.(tsx?|css|html|json)$/.test(f) && readFileSync(p, 'utf8').toLowerCase().includes(placeholder.toLowerCase())) hits.push(p.replace(dir + '/', ''))
    }
  }
  walk(join(dir, 'src'))
  for (const f of ['index.html', 'site.config.json']) existsSync(join(dir, f)) && readFileSync(join(dir, f), 'utf8').toLowerCase().includes(placeholder.toLowerCase()) && hits.push(f)
  hits.length ? fail(`"${placeholder}" still appears in: ${hits.join(', ')}`) : pass('no placeholder text left')
}

console.log(fails ? `\n${fails} blocking problem(s).` : '\nAll checks passed.')
process.exit(fails ? 1 : 0)
