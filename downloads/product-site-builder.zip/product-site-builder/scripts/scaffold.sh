#!/usr/bin/env bash
# Copies the site template into a new project folder. Optionally installs dependencies.
# Usage: bash scaffold.sh <target-dir> [--install]
set -euo pipefail
# If ~/.npm contains root-owned files (left by an old sudo install), npx fails: use a private cache instead.
if [ -z "${NPM_CONFIG_CACHE:-}" ] && [ -n "$(find "$HOME/.npm" -maxdepth 4 -user root 2>/dev/null | head -1)" ]; then
  export NPM_CONFIG_CACHE="${TMPDIR:-/tmp}/product-site-npm-cache"
fi
here="$(cd "$(dirname "$0")/.." && pwd)"
target="${1:?usage: scaffold.sh <target-dir> [--install]}"
if [ -e "$target" ] && [ -n "$(ls -A "$target" 2>/dev/null)" ]; then
  echo "Refusing: $target already exists and is not empty." >&2; exit 1
fi
mkdir -p "$target"
rsync -a --exclude node_modules --exclude dist "$here/template/" "$target/"
echo "Template copied to $target"
if [ "${2:-}" = "--install" ]; then
  (cd "$target" && npm install)
else
  echo "Next: cd \"$target\" && npm install   (ask the user first; this downloads packages)"
fi
