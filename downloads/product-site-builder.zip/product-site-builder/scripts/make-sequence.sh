#!/usr/bin/env bash
# Turns a flat-background assembly video into a transparent WebP frame sequence for the hero.
#   - keys out the flat background colour (auto-sampled from the corners unless given)
#   - removes the coloured halo left on edges
#   - resamples to exactly N frames
#   - blends only the last 3 frames into the exact end render so the hand-off to 3D is pixel-identical
# Usage: bash make-sequence.sh <video.mp4> <end-render.png> <out-dir> [frames=96] [size=960] [quality=88] [keyhex=auto]
# <end-render.png> must be a TRANSPARENT render of the product at its rest pose (square).
set -euo pipefail
video="${1:?video}"; endpng="${2:?end render png}"; out="${3:?out dir}"
N="${4:-96}"; SIZE="${5:-960}"; Q="${6:-88}"; KEY="${7:-auto}"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$out" "$tmp/aux"   # aux holds helper images so they are never exported as frames

dur=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$video")
if [ "$KEY" = "auto" ]; then
  KEY=$(ffmpeg -loglevel error -y -i "$video" -vf "crop=24:24:4:4,scale=1:1,format=rgb24" -frames:v 1 -f rawvideo - | xxd -p | head -c 6)
  echo "Sampled background colour: #$KEY"
fi

# 1. key + de-fringe (premultiply by alpha^2 so the edge halo disappears) + resample to N frames
ffmpeg -loglevel error -y -i "$video" \
  -vf "colorkey=0x${KEY}:0.07:0.08,format=rgba,geq=r='r(X,Y)*pow(alpha(X,Y)/255,2)':g='g(X,Y)*pow(alpha(X,Y)/255,2)':b='b(X,Y)*pow(alpha(X,Y)/255,2)':a='alpha(X,Y)',scale=${SIZE}:${SIZE}:flags=lanczos,fps=${N}/${dur}" \
  -frames:v "$N" "$tmp/%03d.png"

# 2. last frame = the exact end render; blend the 2 frames before it
ffmpeg -loglevel error -y -i "$endpng" -vf "scale=${SIZE}:${SIZE}:flags=lanczos,format=rgba" "$tmp/aux/end.png"
for back in 2 1; do
  i=$((N - back)); t=$(python3 -c "print(round((3-$back)/3,3))"); f=$(printf "%03d" "$i")
  ffmpeg -loglevel error -y -i "$tmp/$f.png" -i "$tmp/aux/end.png" \
    -filter_complex "[0]format=rgba[a];[1]format=rgba[b];[a][b]blend=all_expr='A*(1-$t)+B*$t'" "$tmp/aux/b.png"
  mv "$tmp/aux/b.png" "$tmp/$f.png"
done
cp "$tmp/aux/end.png" "$(printf "$tmp/%03d.png" "$N")"

# 3. WebP with high alpha quality (needs sharp-cli via npx; ffmpeg builds often lack libwebp)
if [ -z "${NPM_CONFIG_CACHE:-}" ] && [ -n "$(find "$HOME/.npm" -maxdepth 4 -user root 2>/dev/null | head -1)" ]; then export NPM_CONFIG_CACHE="${TMPDIR:-/tmp}/product-site-npm-cache"; fi
npx -y sharp-cli@5 -i "$tmp/*.png" -o "$out/" -f webp -q "$Q" --alphaQuality 92 --smartSubsample >/dev/null
n=$(ls "$out"/*.webp | wc -l | tr -d ' ')
echo "Wrote $n frames to $out ($(du -sh "$out" | cut -f1))"
[ "$n" = "$N" ] || { echo "Expected $N frames but wrote $n" >&2; exit 1; }
