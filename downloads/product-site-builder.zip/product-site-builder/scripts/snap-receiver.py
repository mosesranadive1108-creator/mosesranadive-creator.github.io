#!/usr/bin/env python3
"""Tiny local receiver that saves the PNG sent by window.__snapshot (dev only) to a file.
Usage: python3 snap-receiver.py <out.png> [port=5199]
Then, in the browser console of the running dev site:
  const url = __snapshot('[data-hero-anchor]', 1024)   // or '[data-dock]'
  await fetch('http://127.0.0.1:5199/save', {method:'POST', headers:{'content-type':'text/plain'}, body:url})
"""
import base64, http.server, sys

OUT = sys.argv[1]
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5199

class H(http.server.BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'content-type')
    def do_OPTIONS(self):
        self.send_response(204); self._cors(); self.end_headers()
    def do_POST(self):
        data = self.rfile.read(int(self.headers['content-length'])).decode()
        open(OUT, 'wb').write(base64.b64decode(data.split(',', 1)[1]))
        self.send_response(200); self._cors(); self.end_headers(); self.wfile.write(b'saved')
    def log_message(self, *a): pass

http.server.HTTPServer(('127.0.0.1', PORT), H).serve_forever()
