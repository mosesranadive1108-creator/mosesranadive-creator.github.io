#!/usr/bin/env bash
# Compresses a generated GLB for the web (Draco geometry, WebP textures, simplified).
# Usage: bash optimize-glb.sh <in.glb> <out.glb> [simplify-ratio=0.6]
set -euo pipefail
# If ~/.npm contains root-owned files (left by an old sudo install), npx fails: use a private cache instead.
if [ -z "${NPM_CONFIG_CACHE:-}" ] && [ -n "$(find "$HOME/.npm" -maxdepth 4 -user root 2>/dev/null | head -1)" ]; then
  export NPM_CONFIG_CACHE="${TMPDIR:-/tmp}/product-site-npm-cache"
fi
in="${1:?in.glb}"; out="${2:?out.glb}"; ratio="${3:-0.6}"
npx -y @gltf-transform/cli@4 optimize "$in" "$out" --compress draco --texture-compress webp --texture-size 2048 --simplify-ratio "$ratio"
ls -la "$out"
echo "Target: under 3 MB. If it has several meshes, run:  npx @gltf-transform/cli@4 join $out $out"
