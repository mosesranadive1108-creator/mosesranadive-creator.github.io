# Intake interview (Phase 2)

Treat the site as a template: assume **nothing** about the brand, product, palette, copy or effects. Ask with `AskUserQuestion`, one block at a time (never more than four questions per call), offer 2 to 4 concrete options each (the user can always type their own), and put your recommendation first, marked "(Recommended)".

Do not ask what you can infer from an earlier answer. Do not move to the next block until the current one is answered.

## Block A: Brand
1. Brand name (and how it should look: capitals?). Which letter, if any, gets the accent colour in the wordmark (`brand.accentLetterIndex`)?
2. Tagline (one short line) and a one-sentence description (footer blurb, meta description).
3. Tone of voice: precise and technical / warm and human / bold and playful / luxury and quiet.
4. Logo mark: monogram (first letter in a rounded square) / a drawn icon (only if it suits the product: the built-in one is a headphone) / the user's own SVG / none.

## Block B: Product
1. What are you selling? Hero product (name, one line, price) and up to four accessories or variants (name, one line, price each). Currency symbol.
2. Product type, to judge 3D feasibility: rigid hardware with a clear silhouette (headphones, speakers, bottles, shoes, watches, cameras, tools) / soft or organic (apparel, bags, food, plants) / transparent or highly reflective (glassware, jewellery) / something else.
3. Materials and colours of the hero product (these drive the image prompts).
4. Who is it for, and one thing the site must make people feel?

## Block C: Theme
1. Light or dark? (This template is built dark: tell the user a light theme means restyling, and agree before promising it.)
2. Brand colour (hex) or a mood in words. From it, propose the palette (page tones, text tones, sky/link blue-equivalent) and the **CTA colour**. Show the proposal; adjust.
3. CTA colour and button text colour: **must reach 4.5:1 contrast** (the validator checks this). A light or neon CTA needs dark text.
4. Fonts: heading and body from Google Fonts (default Saira Condensed + Roboto). Offer three pairings that suit the mood.
5. References: any sites or screenshots they like. Look at them, say what you will borrow, and what you will not copy.

## Block D: Content
1. Hero: headline lines (one or two, large), subline, primary CTA label and link, secondary CTA.
2. Specs: five items, each label / value / short note / big number for the ghost numeral.
3. Section headings: specs heading and body line, lineup title and lede.
4. Footer: columns and links (only links that really exist; anchors on the page are fine), credit line, year.
5. Wordmark lines for the footer (usually the brand and product name on two lines).

## Block E: Experience
Ask which effects to keep. Explain each in one line and give the cost (performance or credits):
- Blueprint-to-real assembly in the hero (the signature; needs the assembly video, about 10 credits plus)
- Mesh-gradient animated background
- Cursor light trail
- Liquid-glass cards
- Particle product in the footer, and a wordmark that sheds notes on cursor touch. **The notes are an audio theme**: if the product isn't music-related, offer a different sprite set (sparkles, leaves, stars, petals) and change `buildSprites` in `src/sections/NoteWord.tsx` accordingly
- Cart drawer (front-end only; there is no payment, and Checkout does nothing yet)
- Hover-to-particles on the 3D model

## Block F: Assets and budget
1. Generate with Higgsfield, or does the user supply assets (product photos, a GLB, a logo)?
2. Credit budget for the whole build, and whether to cap per item. Quote against it at every gate.
3. Where should the project live? (A folder path. Never create the folder without telling them.)

## Output of Phase 2
1. `site-brief.md`: every answer, in plain language, plus the feasibility notes and the budget.
2. `site.config.json` filled in. For anything unknown, leave the template value **and flag it** in the brief; do not invent facts (specs, prices, claims).
3. Read the brief back to the user and ask for approval. Only then log the gate and continue.

## Copy rules
Keep claims believable and avoid inventing specifications. If the user has no real specs, say the numbers are placeholders and mark them in the brief so they get replaced before launch.
