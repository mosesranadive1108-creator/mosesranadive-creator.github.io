# BUILD_LOG.md format

Create `BUILD_LOG.md` at the project root when Phase 2 starts, and append one block per gate. This is the audit trail of what the user approved and what was spent.

```markdown
# Build log: <brand>

Budget: <N> credits   Spent so far: <N>

## Phase 0: Preflight  (<date>)
- Higgsfield: signed in, plan <plan>, <N> credits
- Gate: passed (user: "<quote>")

## Phase 1: Permissions
- higgsfield CLI: allowed / skipped
- higgsfield skills (<names>): allowed / skipped
- taste skills (<names>) after security review: allowed / skipped
- modern-web-guidance: allowed / skipped
- npm install: allowed / skipped

## Phase 2: Intake
- Brief approved (user: "<quote>")

## Phase 3: Feasibility
- Rubric result: <pass / fail + reasons>
- Test generation: <model>, <credits>, result: <pass / fail>
- If failed, the user's decision: <own GLB / different hero / end> (user: "<quote>")

## Phase 4: Assets
| Item | Model | Quoted | Spent | Approved |
|---|---|---|---|---|

## Phase 5 and 6: Build and QA
- Checks run, failures fixed, final validator output
```

Rules: log the user's actual words for every gate, never your own assumption. A line without a quote is not a gate.
