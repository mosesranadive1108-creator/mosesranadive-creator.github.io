import { useEffect, useRef } from 'react'
import { site } from '../config/site'
import { money, useCart } from './CartContext'

export function CartDrawer() {
  const { lines, count, subtotal, open, setOpen, inc, dec, remove } = useCart()
  const closeBtn = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    closeBtn.current?.focus()
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  return (
    <div className={`cart${open ? ' is-open' : ''}`} inert={!open}>
      <div className="cart__scrim" onClick={() => setOpen(false)} />
      <aside className="cart__panel glass" role="dialog" aria-modal="true" aria-label="Shopping cart" data-lenis-prevent>
        <header className="cart__head">
          <h2 className="cart__title u">
            Your cart <span className="cart__n">{count}</span>
          </h2>
          <button ref={closeBtn} type="button" className="cart__close" aria-label="Close cart" onClick={() => setOpen(false)}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </header>

        {lines.length === 0 ? (
          <div className="cart__empty">
            <p className="cart__empty-title u">Nothing here yet</p>
            <p>Add {site.products[0]?.name} or an accessory from the lineup.</p>
            <a className="btn btn--ghost" href="#products" onClick={() => setOpen(false)}>
              Shop the lineup
            </a>
          </div>
        ) : (
          <>
            <ul className="cart__lines" role="list">
              {lines.map((l) => (
                <li key={l.id} className="cart__line">
                  <div className="cart__thumb">{l.image && <img src={l.image} alt="" />}</div>
                  <div className="cart__info">
                    <p className="cart__name u">{l.name}</p>
                    <p className="cart__price">{money(l.price)}</p>
                    <div className="cart__qty" role="group" aria-label={`Quantity of ${l.name}`}>
                      <button type="button" aria-label={`Decrease quantity of ${l.name}`} onClick={() => dec(l.id)}>
                        −
                      </button>
                      <span aria-live="polite">{l.qty}</span>
                      <button type="button" aria-label={`Increase quantity of ${l.name}`} onClick={() => inc(l.id)}>
                        +
                      </button>
                    </div>
                  </div>
                  <div className="cart__side">
                    <p className="cart__total u">{money(l.price * l.qty)}</p>
                    <button type="button" className="cart__remove" onClick={() => remove(l.id)}>
                      Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>
            <footer className="cart__foot">
              <div className="cart__sub">
                <span className="u">Subtotal</span>
                <span className="cart__sub-val u">{money(subtotal)}</span>
              </div>
              <p className="cart__note">Shipping and taxes are calculated at checkout.</p>
              <button type="button" className="btn btn--primary cart__checkout">
                Checkout
              </button>
            </footer>
          </>
        )}
      </aside>
    </div>
  )
}
