import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { site, type Product } from '../config/site'

export type CartLine = { id: string; name: string; price: number; image?: string; qty: number }

type Cart = {
  lines: CartLine[]
  count: number
  subtotal: number
  open: boolean
  setOpen: (open: boolean) => void
  add: (p: Product) => void
  inc: (id: string) => void
  dec: (id: string) => void
  remove: (id: string) => void
}

const KEY = site.cart.storageKey
const Ctx = createContext<Cart | null>(null)

export const parsePrice = (price: string) => Number(price.replace(/[^0-9.]/g, '')) || 0
export const money = (n: number) => `${site.cart.currency}${n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`

function load(): CartLine[] {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as CartLine[]) : []
  } catch {
    return []
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(load)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(lines))
    } catch {
      /* storage unavailable: the cart just won't persist */
    }
  }, [lines])

  const add = useCallback((p: Product) => {
    setLines((cur) => {
      const hit = cur.find((l) => l.id === p.id)
      if (hit) return cur.map((l) => (l.id === p.id ? { ...l, qty: l.qty + 1 } : l))
      return [...cur, { id: p.id, name: p.name, price: parsePrice(p.price), image: p.image, qty: 1 }]
    })
    setOpen(true)
  }, [])
  const inc = useCallback((id: string) => setLines((c) => c.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l))), [])
  const dec = useCallback(
    (id: string) => setLines((c) => c.flatMap((l) => (l.id !== id ? [l] : l.qty > 1 ? [{ ...l, qty: l.qty - 1 }] : []))),
    [],
  )
  const remove = useCallback((id: string) => setLines((c) => c.filter((l) => l.id !== id)), [])

  const value = useMemo<Cart>(
    () => ({
      lines,
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal: lines.reduce((n, l) => n + l.qty * l.price, 0),
      open,
      setOpen,
      add,
      inc,
      dec,
      remove,
    }),
    [lines, open, add, inc, dec, remove],
  )
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useCart() {
  const c = useContext(Ctx)
  if (!c) throw new Error('useCart must be used inside <CartProvider>')
  return c
}
