import { useEffect, useRef } from 'react'
import { useCart } from './CartContext'

// Nav cart button: bag icon with a live item count that bumps whenever it changes.
export function CartButton() {
  const { count, open, setOpen } = useCart()
  const badge = useRef<HTMLSpanElement>(null)
  const prev = useRef(count)

  // Bounce the badge only when something is added (never on load, never when emptying).
  useEffect(() => {
    const grew = count > prev.current
    prev.current = count
    const el = badge.current
    if (!grew || !el) return
    el.classList.remove('is-bump')
    void el.offsetWidth // restart the animation
    el.classList.add('is-bump')
  }, [count])

  return (
    <button
      type="button"
      className="cart-btn"
      aria-label={`Open cart, ${count} ${count === 1 ? 'item' : 'items'}`}
      aria-haspopup="dialog"
      aria-expanded={open}
      onClick={() => setOpen(true)}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M5 8h14l-1.2 11a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 8z" />
        <path d="M9 8V6.5a3 3 0 0 1 6 0V8" />
      </svg>
      <span ref={badge} className={`cart-btn__count${count ? ' has-items' : ''}`} aria-hidden="true">
        {count}
      </span>
    </button>
  )
}
