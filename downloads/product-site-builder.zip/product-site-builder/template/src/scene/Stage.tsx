import { Environment, Lightformer } from '@react-three/drei'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Suspense, useEffect, useRef } from 'react'
import * as THREE from 'three'
import { layout, scroll } from '../anim/state'
import { smooth } from './constants'
import { Product3D } from './Product3D'

const { damp, lerp } = THREE.MathUtils

// Fixed camera and the lighting mood, driven by scroll. (Page background and fit live in anim/ambience.ts.)
// End-of-rise lighting must stay as is: the card image is a render of the product under it.
function Director() {
  const { camera } = useThree()
  const rise = useRef(0)
  const key = useRef<THREE.DirectionalLight>(null!)
  const spot = useRef<THREE.SpotLight>(null!)
  const rim = useRef<THREE.PointLight>(null!)
  const warm = useRef<THREE.PointLight>(null!)
  const ambient = useRef<THREE.AmbientLight>(null!)

  useFrame((_, dt) => {
    rise.current = damp(rise.current, scroll.rise, smooth, dt)
    const r = rise.current
    const back = 1 + (1 - layout.fit) * 0.8 // pull the camera back on tall screens

    camera.position.set(0, 0.9 * back, 6.4 * back)
    camera.lookAt(0, -0.05, 0)

    // Hero lighting: warm key from the left, cool rim behind. Fades to a spotlight as the product rises.
    key.current.intensity = lerp(1.4, 0.25, r)
    warm.current.intensity = lerp(7, 0, r)
    ambient.current.intensity = lerp(0.2, 0.08, r)
    spot.current.intensity = lerp(0, 60, r)
    rim.current.intensity = lerp(9, 14, r)
  })

  return (
    <>
      <ambientLight ref={ambient} intensity={0.2} />
      <directionalLight ref={key} position={[3, 6, 4]} intensity={1.4} />
      <pointLight ref={warm} position={[-2.5, 0.8, 2.5]} color="#ffb36b" intensity={7} distance={10} />
      <spotLight ref={spot} position={[0.5, 5, 3]} angle={0.32} penumbra={0.85} intensity={0} />
      <pointLight ref={rim} position={[-1.5, 1.4, -1.5]} color="#64baf6" intensity={9} distance={8} />
    </>
  )
}

// Dev-only: renders the current frame at high resolution and crops it to a DOM element.
// Used once to bake the flagship card image from the 3D model's landed pose.
function DevSnapshot() {
  const { gl, scene, camera } = useThree()
  useEffect(() => {
    if (!import.meta.env.DEV) return
    const w = window as unknown as { __snapshot: (sel: string, px: number) => string }
    w.__snapshot = (sel, px) => {
      const r = document.querySelector(sel)!.getBoundingClientRect()
      const prev = gl.getPixelRatio()
      const dpr = 4
      gl.setPixelRatio(dpr)
      gl.render(scene, camera)
      const c = document.createElement('canvas')
      c.width = c.height = px
      c.getContext('2d')!.drawImage(gl.domElement, r.left * dpr, r.top * dpr, r.width * dpr, r.height * dpr, 0, 0, px, px)
      gl.setPixelRatio(prev)
      return c.toDataURL('image/png')
    }
  }, [gl, scene, camera])
  return null
}

export function Stage() {
  return (
    <div className="stage" aria-hidden="true">
      <Canvas
        dpr={[1, 1.5]}
        gl={{ alpha: true, antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
        camera={{ fov: 32, near: 0.1, far: 40, position: [0, 0.9, 6.4] }}
      >
        <Director />
        <DevSnapshot />
        <Suspense fallback={null}>
          <Environment resolution={256}>
            <Lightformer form="rect" intensity={3} position={[0, 4, 2]} scale={[6, 2, 1]} />
            <Lightformer form="rect" intensity={1.5} position={[-4, 1, 1]} rotation-y={Math.PI / 2} scale={[4, 2, 1]} />
            <Lightformer form="rect" color="#64baf6" intensity={2} position={[4, 1, -2]} rotation-y={-Math.PI / 2} scale={[4, 2, 1]} />
          </Environment>
          <Product3D />
        </Suspense>
      </Canvas>
    </div>
  )
}
