export const smooth = 7 // damping factor applied to scroll progress in the scene
