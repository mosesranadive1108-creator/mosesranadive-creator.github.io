import * as THREE from 'three'
import { MeshSurfaceSampler } from 'three/examples/jsm/math/MeshSurfaceSampler.js'

// Hover-to-particles: the cursor ray carves the solid headphones away and the surface there
// bursts into glowing dust that swirls around the cursor, then springs back when it leaves.
// Everything is computed in the mesh's local space against the cursor ray, so no raycasting.

export type HoverUniforms = {
  uRayO: { value: THREE.Vector3 } // cursor ray origin (mesh local space)
  uRayD: { value: THREE.Vector3 } // cursor ray direction (mesh local space, normalised)
  uRadius: { value: number } // carve radius (local units)
  uStrength: { value: number } // 0..1 overall hover amount (damped)
  uTime: { value: number }
  uVisible: { value: number } // 0..1 how visible the 3D model is (drives the ambient aura)
}

export function createHoverUniforms(): HoverUniforms {
  return {
    uRayO: { value: new THREE.Vector3(0, 0, 100) },
    uRayD: { value: new THREE.Vector3(0, 0, -1) },
    uRadius: { value: 0.16 },
    uStrength: { value: 0 },
    uTime: { value: 0 },
    uVisible: { value: 0 },
  }
}

const RAY_GLSL = /* glsl */ `
uniform vec3 uRayO;
uniform vec3 uRayD;
uniform float uRadius;
uniform float uStrength;
uniform float uTime;
uniform float uVisible;
float rayDist(vec3 p) {
  vec3 v = p - uRayO;
  return length(v - uRayD * dot(v, uRayD));
}
vec3 rayAway(vec3 p) {
  vec3 v = p - uRayO;
  vec3 a = v - uRayD * dot(v, uRayD);
  return a / max(length(a), 1e-4);
}
float hash13(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453); }
`

// Points sampled on the surface. Hidden at rest; near the cursor they lift off and drift.
export function createParticleLayer(mesh: THREE.Mesh, uniforms: HoverUniforms, count = 14000) {
  const sampler = new MeshSurfaceSampler(mesh).build()
  const pos = new Float32Array(count * 3)
  const nrm = new Float32Array(count * 3)
  const rnd = new Float32Array(count)
  const p = new THREE.Vector3()
  const n = new THREE.Vector3()
  for (let i = 0; i < count; i++) {
    sampler.sample(p, n)
    p.toArray(pos, i * 3)
    n.toArray(nrm, i * 3)
    rnd[i] = Math.random()
  }
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  geo.setAttribute('aNormal', new THREE.BufferAttribute(nrm, 3))
  geo.setAttribute('aRnd', new THREE.BufferAttribute(rnd, 1))

  const mat = new THREE.ShaderMaterial({
    uniforms: { ...uniforms, uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) } },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      ${RAY_GLSL}
      uniform float uPixelRatio;
      attribute vec3 aNormal;
      attribute float aRnd;
      varying float vAlpha;
      varying float vHot;
      void main() {
        float d = rayDist(position);
        float f = (1.0 - smoothstep(uRadius * 0.4, uRadius * 1.9, d)) * uStrength;
        // Burst outward along the surface normal and away from the cursor, with a slow swirl.
        float t = uTime * (0.6 + aRnd);
        vec3 swirl = vec3(sin(t + aRnd * 30.0), cos(t * 1.3 + aRnd * 17.0), sin(t * 0.7 + aRnd * 9.0));
        // Ambient aura: a thin, breathing shell of dust just off the surface at all times.
        float breathe = 0.5 + 0.5 * sin(t * 0.8 + aRnd * 25.0);
        vec3 aura = (aNormal * (0.03 + 0.11 * aRnd * breathe) + swirl * 0.02) * uVisible;
        vec3 p = position + aura + (aNormal * 0.55 + rayAway(position) * 0.45 + swirl * 0.25) * f * (0.05 + 0.22 * aRnd);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        gl_PointSize = (2.4 + 3.0 * f + 1.6 * aRnd) * uPixelRatio * (3.0 / -mv.z);
        float twinkle = 0.35 + 0.65 * (0.5 + 0.5 * sin(uTime * 2.2 + aRnd * 40.0));
        vAlpha = uVisible * 0.16 * twinkle + f * (0.4 + 0.3 * twinkle);
        vHot = aRnd;
      }`,
    fragmentShader: /* glsl */ `
      varying float vAlpha;
      varying float vHot;
      void main() {
        vec2 c = gl_PointCoord - 0.5;
        float a = smoothstep(0.5, 0.0, length(c));
        vec3 col = mix(vec3(0.3, 0.58, 1.0), vec3(0.85, 0.93, 1.0), vHot * vHot * vHot);
        gl_FragColor = vec4(col, a * vAlpha); // additive blending multiplies by alpha once
      }`,
  })
  const points = new THREE.Points(geo, mat)
  points.frustumCulled = false
  points.renderOrder = 2
  return points
}

// Patches the mesh material so fragments near the cursor ray are discarded (with a noisy,
// glowing edge), making the solid look like it is dissolving into the particles.
export function patchDissolve(material: THREE.MeshStandardMaterial, uniforms: HoverUniforms) {
  material.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms)
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vLocalPos;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvLocalPos = position;')
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', `#include <common>\nvarying vec3 vLocalPos;\n${RAY_GLSL}`)
      .replace(
        '#include <clipping_planes_fragment>',
        `#include <clipping_planes_fragment>
        float hd = rayDist(vLocalPos);
        float edge = uRadius * uStrength * (0.75 + 0.5 * hash13(floor(vLocalPos * 260.0) + floor(uTime * 4.0)));
        if (hd < edge) discard;`,
      )
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        float rim = (1.0 - smoothstep(edge, edge + uRadius * 0.18, hd)) * uStrength;
        totalEmissiveRadiance += vec3(0.25, 0.5, 1.0) * rim * 1.1;`,
      )
  }
  material.customProgramCacheKey = () => 'mozit-dissolve'
  material.needsUpdate = true
}
