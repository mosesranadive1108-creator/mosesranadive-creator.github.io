import { useGLTF } from '@react-three/drei'
import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { domToWorld } from '../anim/dock'
import { layout, pointer, prefersReducedMotion, scroll } from '../anim/state'
import { site } from '../config/site'
import { smooth } from './constants'
import { createHoverUniforms, createParticleLayer, patchDissolve } from './particles'

const { damp, lerp, clamp } = THREE.MathUtils
const HANDOFF_START = 0.93 // fly progress where the 3D model starts handing off to the card image
const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)

// Poses. REST (hero stage) and DOCK (in the card) are measured live from DOM boxes, so the
// 3D model lines up with the assembly sequence's last frame and with the card at any size.
const [REST_RX, REST_RY, REST_RZ] = site.hero.restRotation
const REST = { z: 0, rx: REST_RX, ry: REST_RY, rz: REST_RZ }
const SHOW = { x: 0, y: -0.05, z: 0.9, scale: 1.55, ry: -0.55 }

export function Product3D() {
  const { scene } = useGLTF(site.assets.model)
  const group = useRef<THREE.Group>(null!)
  const { camera, size } = useThree()
  const dockEl = useRef<Element | null>(null)
  const restEl = useRef<Element | null>(null)
  // Measure the model itself (no hard-coded sizes): its centre, and its on-screen extent at the rest
  // rotation. The same framing is used for the hero box and the card box, so they always match.
  const info = useMemo(() => {
    const box = new THREE.Box3().setFromObject(scene)
    const center = box.getCenter(new THREE.Vector3())
    const rot = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(REST.rx, REST.ry, REST.rz))
    let minX = Infinity
    let maxX = -Infinity
    let minY = Infinity
    let maxY = -Infinity
    for (const x of [box.min.x, box.max.x])
      for (const y of [box.min.y, box.max.y])
        for (const z of [box.min.z, box.max.z]) {
          const v = new THREE.Vector3(x - center.x, y - center.y, z - center.z).applyMatrix4(rot)
          minX = Math.min(minX, v.x)
          maxX = Math.max(maxX, v.x)
          minY = Math.min(minY, v.y)
          maxY = Math.max(maxY, v.y)
        }
    return { center, w: Math.max(0.001, maxX - minX), h: Math.max(0.001, maxY - minY) }
  }, [scene])
  const fitScale = (box: { w: number; h: number }) => Math.min((box.h * 0.8) / info.h, (box.w * 0.85) / info.w)
  const restPos = useMemo(() => new THREE.Vector3(), [])
  const restCache = useRef({ valid: false, x: 0, y: 0, scale: 1, w: 0, h: 0 })
  const dockImg = useRef<HTMLElement | null>(null)
  const mats = useRef<THREE.Material[]>([])
  const fade = useRef(-1)
  const dockPos = useMemo(() => new THREE.Vector3(), [])
  const s = useRef({ rise: 0, specs: 0, fly: 0, px: 0, py: 0 })
  const hover = useMemo(() => createHoverUniforms(), [])
  const meshRef = useRef<THREE.Mesh | null>(null)
  const ray = useMemo(() => ({ caster: new THREE.Raycaster(), inv: new THREE.Matrix4(), o: new THREE.Vector3(), d: new THREE.Vector3(), c: new THREE.Vector3(), ndc: new THREE.Vector2() }), [])
  const canHover = useMemo(() => site.effects.cursorParticles && !prefersReducedMotion && window.matchMedia('(pointer: fine)').matches, [])

  useEffect(() => {
    dockEl.current = document.querySelector('[data-dock]')
    restEl.current = document.querySelector('[data-hero-anchor]')
    dockImg.current = document.querySelector('[data-dock-img]')
    mats.current = []
    let particles: THREE.Points | null = null
    // The hover dissolve works on single-mesh models (what image-to-3D tools output). With several
    // meshes it is skipped rather than risk a broken look; join meshes first (gltf-transform join).
    let meshCount = 0
    scene.traverse((o) => ((o as THREE.Mesh).isMesh ? meshCount++ : 0))
    scene.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.isMesh) {
        const mat = m.material as THREE.MeshStandardMaterial
        mat.envMapIntensity = 1.4
        mats.current.push(mat)
        if (canHover && meshCount === 1 && !meshRef.current) {
          meshRef.current = m
          patchDissolve(mat, hover)
          particles = createParticleLayer(m, hover)
          m.add(particles)
        }
      }
    })
    return () => {
      if (particles) {
        particles.removeFromParent()
        particles.geometry.dispose()
        ;(particles.material as THREE.Material).dispose()
      }
      meshRef.current = null
    }
  }, [scene, hover, canHover])

  useFrame((state, dt) => {
    const g = group.current
    const k = s.current
    // Damp scroll progress so motion stays silky even on coarse wheel steps.
    k.rise = damp(k.rise, scroll.rise, smooth, dt)
    k.specs = damp(k.specs, scroll.specs, smooth, dt)
    k.fly = damp(k.fly, scroll.fly, smooth, dt)
    const t = state.clock.elapsedTime
    const motion = prefersReducedMotion ? 0 : 1

    // A: in the hero stage, exactly where the assembly sequence ends (same framing as the card).
    const fit = layout.fit
    const rest = REST
    let x = 0
    let y = 0
    let scale = 1
    if (restEl.current) {
      // Measure the stage while the hero is pinned; once the rise starts the hero scrolls away,
      // so keep using the last pinned measurement instead of chasing the stage off-screen.
      const rc = restCache.current
      if (scroll.rise <= 0.0001 || !rc.valid || rc.w !== size.width || rc.h !== size.height) {
        const box = domToWorld(restEl.current, camera as THREE.PerspectiveCamera, size, rest.z, restPos)
        Object.assign(rc, { valid: true, x: restPos.x, y: restPos.y, scale: fitScale(box), w: size.width, h: size.height })
      }
      x = rc.x
      y = rc.y
      scale = rc.scale
    }
    let z = rest.z
    let rx = rest.rx
    let ry = rest.ry
    let rz = rest.rz

    // B: lift off his head and rise into the spotlight while he fades into the dark.
    const r = ease(k.rise)
    x = lerp(x, SHOW.x, r)
    y = lerp(y, SHOW.y + (1 - fit) * 0.5, r) + Math.sin(Math.PI * r) * 0.08
    z = lerp(z, SHOW.z, r)
    scale = lerp(scale, SHOW.scale * (0.55 + 0.45 * fit), r)
    rx = lerp(rx, -0.12, r)
    ry = lerp(ry, SHOW.ry, r)
    rz = lerp(rz, 0, r)

    // Specs: slow showcase turn while the section is pinned, plus a tilt and turn toward the cursor.
    ry += Math.sin(k.specs * Math.PI) * 0.9 * motion + k.specs * 0.35
    const look = k.rise * (1 - k.fly) * motion
    k.px = damp(k.px, pointer.x, 4, dt)
    k.py = damp(k.py, pointer.y, 4, dt)
    ry += k.px * 0.7 * look
    rx += k.py * 0.4 * look
    rz += -k.px * 0.12 * look
    y += Math.sin(t * 1.2) * 0.025 * k.rise * (1 - k.fly) * motion

    // C/D: fly to the featured card and stay docked as it scrolls.
    if (k.fly > 0.0001 && dockEl.current) {
      const box = domToWorld(dockEl.current, camera as THREE.PerspectiveCamera, size, 0, dockPos)
      const f = ease(clamp(k.fly, 0, 1))
      const dockScale = fitScale(box)
      x = lerp(x, dockPos.x, f) + Math.sin(Math.PI * f) * -0.35 * motion
      y = lerp(y, dockPos.y, f) + Math.sin(Math.PI * f) * 0.35 * motion
      z = lerp(z, 0, f) + Math.sin(Math.PI * f) * 0.25 * motion
      scale = lerp(scale, dockScale, f)
      ry = lerp(ry, -0.45, f) + f * Math.PI * 2 * motion
      rx = lerp(rx, 0, f)
      rz = lerp(rz, 0, f) + Math.sin(Math.PI * f) * 0.35 * motion
    }

    // Landing hand-off: in the last stretch the 3D model fades out while the card's
    // render of the same pose fades in, so it reads as the product settling into the card.
    const noHandoff = import.meta.env.DEV && (window as unknown as { __noHandoff?: boolean }).__noHandoff
    const handoff = noHandoff ? 0 : THREE.MathUtils.smoothstep(k.fly, HANDOFF_START, 0.995)
    // Hand-off: the assembled sequence frame cross-fades to the 3D model in the same spot and pose.
    const showRest = import.meta.env.DEV && (window as unknown as { __showRest?: boolean }).__showRest
    const takeoff = showRest ? 1 : scroll.handoff
    const opacity = takeoff * (1 - handoff)
    if (Math.abs(opacity - fade.current) > 0.001) {
      fade.current = opacity
      const transparent = opacity < 1
      mats.current.forEach((mat) => {
        if (mat.transparent !== transparent) {
          mat.transparent = transparent
          mat.needsUpdate = true
        }
        mat.opacity = opacity
      })
      g.visible = opacity > 0.001
      if (dockImg.current) {
        dockImg.current.style.opacity = String(handoff)
        dockImg.current.style.transform = `scale(${1.03 - 0.03 * handoff})`
      }
    }

    g.position.set(x, y, z)
    g.scale.setScalar(scale)
    g.rotation.set(rx, ry, rz)

    // Hover-to-particles: express the cursor ray in the mesh's local space and decide how
    // strongly to dissolve (only while the cursor is actually near the product).
    const mesh = meshRef.current
    if (mesh) {
      g.updateMatrixWorld()
      ray.ndc.set(pointer.x, -pointer.y)
      ray.caster.setFromCamera(ray.ndc, camera)
      ray.inv.copy(mesh.matrixWorld).invert()
      ray.o.copy(ray.caster.ray.origin).applyMatrix4(ray.inv)
      ray.d.copy(ray.caster.ray.direction).transformDirection(ray.inv)
      hover.uRayO.value.lerp(ray.o, 1 - Math.exp(-dt * 14))
      hover.uRayD.value.lerp(ray.d, 1 - Math.exp(-dt * 14)).normalize()
      // Distance from the ray to the model's centre decides whether we're hovering it.
      mesh.geometry.boundingSphere ?? mesh.geometry.computeBoundingSphere()
      const sphere = mesh.geometry.boundingSphere!
      const v = ray.c.copy(sphere.center).sub(ray.o)
      const off = v.sub(ray.d.clone().multiplyScalar(v.dot(ray.d))).length()
      const near = off < sphere.radius * 0.95 && opacity > 0.6 ? 1 : 0
      hover.uStrength.value = damp(hover.uStrength.value, near * opacity, near ? 5 : 2.5, dt)
      hover.uTime.value = t
      hover.uVisible.value = opacity
    }
  })

  return (
    <group ref={group}>
      {/* Re-centre the model so it rotates around its middle, whatever its origin. */}
      <primitive object={scene} position={[-info.center.x, -info.center.y, -info.center.z]} />
    </group>
  )
}

useGLTF.preload(site.assets.model)
