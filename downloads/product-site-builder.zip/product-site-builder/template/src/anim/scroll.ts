import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
import { site } from '../config/site'
import { prefersReducedMotion, scroll } from './state'

gsap.registerPlugin(ScrollTrigger)

// Wires Lenis smooth scroll into GSAP and maps each section's scroll progress
// into the shared `scroll` state. Returns a cleanup function.
export function setupScroll() {
  let lenis: Lenis | null = null
  const tick = (t: number) => lenis?.raf(t * 1000)

  if (!prefersReducedMotion) {
    lenis = new Lenis({ lerp: 0.09, smoothWheel: true })
    lenis.on('scroll', ScrollTrigger.update)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    if (import.meta.env.DEV) (window as unknown as { __lenis: Lenis }).__lenis = lenis
  }

  // A context reverts every inline style it set, so remounts start clean.
  // Hero beats, in viewport heights of scroll inside the pinned hero (pinned for 2 viewports).
  const vh = (n: number) => () => `top+=${window.innerHeight * n} top`
  // The 3D fade overlaps the last few frames (which already match the 3D render), so there's no pause.
  const HERO = site.hero.beats

  // A context reverts every inline style it set, so remounts start clean.
  const ctx = gsap.context(() => {
    ScrollTrigger.create({
      trigger: '#hero',
      start: 'top top',
      end: vh(HERO.assembled),
      invalidateOnRefresh: true,
      onUpdate: (s) => (scroll.assemble = s.progress),
    })
    ScrollTrigger.create({
      trigger: '#hero',
      start: vh(HERO.handoffStart),
      end: vh(HERO.handoffEnd),
      invalidateOnRefresh: true,
      onUpdate: (s) => (scroll.handoff = s.progress),
    })
    ScrollTrigger.create({
      trigger: '#hero',
      start: vh(HERO.handoffEnd),
      end: 'bottom top', // the rise continues while the specs section slides in underneath
      invalidateOnRefresh: true,
      onUpdate: (s) => (scroll.rise = s.progress),
    })
    ScrollTrigger.create({
      trigger: '#specs',
      start: 'top top',
      end: 'bottom bottom',
      onUpdate: (s) => (scroll.specs = s.progress),
    })
    ScrollTrigger.create({
      trigger: '#products',
      start: 'top bottom',
      endTrigger: '[data-dock]',
      end: 'center 55%',
      onUpdate: (s) => (scroll.fly = s.progress),
    })

    if (prefersReducedMotion) return

    // Spec copy and cards step in while the section is pinned.
    gsap
      .timeline({ scrollTrigger: { trigger: '#specs', start: 'top 70%', end: 'top top', scrub: true } })
      .fromTo('.specs__art', { opacity: 0, x: -30 }, { opacity: 0.2, x: 0, duration: 0.8, ease: 'power2.out' }, 0)
      .fromTo('.specs__copy', { opacity: 0, x: -24 }, { opacity: 1, x: 0, duration: 0.6, ease: 'power2.out' }, 0)
      .fromTo('.spec', { opacity: 0, y: 16 }, { opacity: 1, y: 0, stagger: 0.25, duration: 0.5, ease: 'power2.out' }, 0.2)

    // Hero copy drifts up and fades as the product rises.
    gsap.fromTo(
      '.hero__copy, .hero__hint, .hero__side',
      { opacity: 1, y: 0 },
      {
        opacity: 0,
        y: -60,
        ease: 'none',
        scrollTrigger: { trigger: '#hero', start: vh(HERO.handoffEnd), end: vh(HERO.handoffEnd + 0.45), scrub: true, invalidateOnRefresh: true },
      },
    )
  })

  ScrollTrigger.refresh()

  return () => {
    ctx.revert()
    gsap.ticker.remove(tick)
    lenis?.destroy()
  }
}
