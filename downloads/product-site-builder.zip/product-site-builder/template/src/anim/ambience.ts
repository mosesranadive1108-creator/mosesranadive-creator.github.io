import { site } from '../config/site'
import { ambience, layout, prefersReducedMotion, scroll } from './state'

// Page-level ambience, independent of three.js:
// - the page background eases from the hero tone to the dark tone as the product rises
// - ambience.glow dims the animated background a little once the page darkens
// - layout.fit shrinks compositions on tall (phone) screens
const hex = (h: string) => {
  const n = parseInt(h.replace('#', ''), 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export function startAmbience() {
  const a = hex(site.theme.heroBg)
  const b = hex(site.theme.darkBg)
  let rise = 0
  let prev = performance.now()
  let raf = 0
  const frame = (now: number) => {
    raf = requestAnimationFrame(frame)
    const dt = Math.min(0.05, (now - prev) / 1000)
    prev = now
    rise += (scroll.rise - rise) * (1 - Math.exp(-dt * 7))
    const r = prefersReducedMotion ? scroll.rise : rise
    const c = a.map((v, i) => Math.round(v + (b[i] - v) * r))
    document.body.style.backgroundColor = `rgb(${c[0]}, ${c[1]}, ${c[2]})`
    ambience.glow = 1 - r * 0.3
    layout.fit = Math.min(1, Math.max(0.5, window.innerWidth / window.innerHeight / 1.25))
  }
  raf = requestAnimationFrame(frame)
  return () => cancelAnimationFrame(raf)
}
