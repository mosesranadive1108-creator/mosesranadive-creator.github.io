import * as THREE from 'three'

const ndc = new THREE.Vector3()
const dir = new THREE.Vector3()

// Projects the centre of a DOM element onto the plane z = planeZ in world space
// and returns the world-space width and height that match the element's pixel size.
export function domToWorld(
  el: Element,
  camera: THREE.PerspectiveCamera,
  size: { width: number; height: number },
  planeZ: number,
  out: THREE.Vector3,
  dy = 0, // extra vertical pixel offset applied to the element's centre
): { w: number; h: number } {
  const r = el.getBoundingClientRect()
  ndc.set(((r.left + r.width / 2) / size.width) * 2 - 1, -((r.top + r.height / 2 + dy) / size.height) * 2 + 1, 0.5)
  ndc.unproject(camera)
  dir.copy(ndc).sub(camera.position).normalize()
  const t = (planeZ - camera.position.z) / dir.z
  out.copy(camera.position).addScaledVector(dir, t)
  const dist = camera.position.distanceTo(out)
  const visibleH = 2 * dist * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))
  const perPx = visibleH / size.height
  return { w: r.width * perPx, h: r.height * perPx }
}
