import { site } from '../config/site'

// Applies site.config.json's theme to the page at startup: colours, fonts and the CTA text colour
// become CSS custom properties, so the whole stylesheet re-themes from the config alone.
const kebab = (s: string) => s.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)

export function applyTheme() {
  const root = document.documentElement.style
  for (const [k, v] of Object.entries(site.theme.colors)) root.setProperty(`--color-${kebab(k)}`, v)
  root.setProperty('--color-cta-text', site.theme.ctaText)
  root.setProperty('--font-heading', `'${site.fonts.heading}', 'Arial Narrow', ui-sans-serif, system-ui, sans-serif`)
  root.setProperty('--font-body', `'${site.fonts.body}', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif`)
}
