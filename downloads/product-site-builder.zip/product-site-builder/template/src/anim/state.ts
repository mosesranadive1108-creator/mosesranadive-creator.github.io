// Shared, mutable animation state. Written by ScrollTrigger / pointer listeners,
// read every frame by the 3D scene so the product follows one continuous path.
export const scroll = {
  assemble: 0, // hero, pinned: the image sequence assembles the product
  handoff: 0, // hero, pinned: image sequence cross-fades to the 3D model
  rise: 0, // end of hero: the product rises into the spotlight
  specs: 0, // pinned specs section: showcase turn
  fly: 0, // products enter: flight to the card
}

export const pointer = { x: 0, y: 0 } // -1..1, centre = 0

// Dev aid for QA: inspect scroll progress from the console (window.__scroll).
if (import.meta.env.DEV && typeof window !== 'undefined') (window as unknown as { __scroll: typeof scroll }).__scroll = scroll

// 1 on landscape screens, down to 0.5 on tall phones; scales the composition to fit.
export const layout = { fit: 1 }

// Background brightness: 1 in the hero, dimmer once the page goes dark. Set by the 3D scene.
export const ambience = { glow: 1 }

export const prefersReducedMotion =
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

if (typeof window !== 'undefined') {
  window.addEventListener(
    'pointermove',
    (e) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.y = (e.clientY / window.innerHeight) * 2 - 1
    },
    { passive: true },
  )
}
