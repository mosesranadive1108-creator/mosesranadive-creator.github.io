import { useEffect, useRef } from 'react'
import { prefersReducedMotion } from '../anim/state'

// A headphone made of ~11,000 glowing particles sampled from its shape (band, cups with azure
// rings, cushions, yokes). It assembles itself the first time it scrolls into view, sways gently,
// is pushed away by the cursor and springs back, and scatters and reforms when clicked.
// The canvas is transparent so it sits on the page background and over the footer wordmark.
const W = 1020
const H = 630

type Pts = { x: number[]; y: number[]; z: number[]; r: number[]; g: number[]; b: number[]; w: number[] }

function buildHeadphonePoints(): Pts {
  const P: Pts = { x: [], y: [], z: [], r: [], g: [], b: [], w: [] }
  const add = (x: number, y: number, z: number, r: number, g: number, b: number, w = 1) => {
    P.x.push(x), P.y.push(y), P.z.push(z), P.r.push(r), P.g.push(g), P.b.push(b), P.w.push(w)
  }
  const R = Math.random
  const TAU = Math.PI * 2
  const { cos, sin, sqrt } = Math

  // Headband: a flat band following an elliptical arc.
  for (let i = 0; i < 2800; i++) {
    const t = R() * Math.PI
    const a = 1.04
    const bb = 1.2
    let n = cos(t) / a
    let m = sin(t) / bb
    const l = Math.hypot(n, m)
    n /= l
    m /= l
    const th = 0.05
    const wd = 0.11
    let off: number
    let zz: number
    if (R() < 0.5) {
      off = (R() < 0.5 ? -1 : 1) * th
      zz = (R() * 2 - 1) * wd
    } else {
      off = (R() * 2 - 1) * th
      zz = (R() < 0.5 ? -1 : 1) * wd
    }
    const v = 0.78 + 0.22 * R()
    add(a * cos(t) + n * off, bb * sin(t) + m * off, zz, 0.72 * v, 0.8 * v, 0.95 * v)
  }

  for (const side of [-1, 1]) {
    const cx = side * 1.04
    const cy = -0.78
    const ry = 0.52
    const rz = 0.44
    const half = 0.17
    // Ear cup shell: domed outer face, side wall, inner face.
    for (let i = 0; i < 2300; i++) {
      const u = R()
      const ph = R() * TAU
      let x: number, y: number, z: number, c: number[]
      if (u < 0.42) {
        const rad = sqrt(R())
        x = cx + side * (half + 0.08 * (1 - rad * rad))
        y = cy + ry * rad * cos(ph)
        z = rz * rad * sin(ph)
        c = [0.5, 0.66, 0.95]
      } else if (u < 0.78) {
        x = cx + side * (R() * 2 - 1) * half
        y = cy + ry * cos(ph)
        z = rz * sin(ph)
        c = [0.45, 0.6, 0.9]
      } else {
        const rad = sqrt(R())
        x = cx - side * half
        y = cy + ry * rad * cos(ph)
        z = rz * rad * sin(ph)
        c = [0.3, 0.4, 0.7]
      }
      const k = 0.75 + 0.25 * R()
      add(x, y, z, c[0] * k, c[1] * k, c[2] * k)
    }
    // Glowing azure ring on the outer face.
    for (let i = 0; i < 460; i++) {
      const ph = R() * TAU
      const rad = 0.82 + 0.025 * (R() * 2 - 1)
      add(cx + side * (half + 0.08 * (1 - rad * rad) + 0.006), cy + ry * rad * cos(ph), rz * rad * sin(ph), 0.3, 0.72, 1, 1.9)
    }
    // Cushion: a flattened torus on the inner side of the cup.
    for (let i = 0; i < 1500; i++) {
      const ph = R() * TAU
      const ps = R() * TAU
      const y0 = 0.4 * cos(ph)
      const z0 = 0.33 * sin(ph)
      let nY = 0.33 * cos(ph)
      let nZ = 0.4 * sin(ph)
      const nl = Math.hypot(nY, nZ)
      nY /= nl
      nZ /= nl
      const tb = 0.12
      const kk = 0.75 + 0.25 * R()
      add(cx - side * (half + 0.08 + 0.75 * tb * sin(ps)), cy + y0 + nY * tb * cos(ps), z0 + nZ * tb * cos(ps), 0.9 * kk, 0.93 * kk, kk, 0.9)
    }
    // Yoke: a fork arching over the cup, plus the stem up to the band.
    for (let i = 0; i < 360; i++) {
      const ph = R() * Math.PI
      add(cx + (R() * 2 - 1) * 0.03, cy + (ry + 0.05) * sin(ph) + (R() * 2 - 1) * 0.025, (rz + 0.05) * cos(ph) + (R() * 2 - 1) * 0.025, 0.85, 0.88, 0.96, 1.1)
    }
    for (let i = 0; i < 170; i++) {
      const yt = cy + ry + 0.05
      add(cx + (R() * 2 - 1) * 0.03, yt * R(), (R() * 2 - 1) * 0.03, 0.85, 0.88, 0.96, 1.1)
    }
  }
  return P
}

function start(cv: HTMLCanvasElement, P: Pts): () => void {
  const ctx = cv.getContext('2d')!
  cv.width = W
  cv.height = H
  const img = ctx.createImageData(W, H)
  const buf = img.data

  const N = P.x.length
  const X = new Float32Array(P.x)
  const Y = new Float32Array(P.y)
  const Z = new Float32Array(P.z)
  const CR = new Float32Array(P.r)
  const CG = new Float32Array(P.g)
  const CB = new Float32Array(P.b)
  const CW = new Float32Array(P.w)
  const dx = new Float32Array(N)
  const dy = new Float32Array(N)
  const dz = new Float32Array(N)
  const vx = new Float32Array(N)
  const vy = new Float32Array(N)
  const vz = new Float32Array(N)

  const R = Math.random
  const TAU = Math.PI * 2
  const U = H / 2.95
  const F = 4.2

  // Start scattered (so the first view assembles itself); with reduced motion, start assembled.
  const explode = () => {
    for (let i = 0; i < N; i++) {
      const a = R() * TAU
      const b = Math.acos(2 * R() - 1)
      const rr = 2 + R() * 2.5
      dx[i] = rr * Math.sin(b) * Math.cos(a)
      dy[i] = rr * Math.sin(b) * Math.sin(a)
      dz[i] = rr * Math.cos(b)
    }
  }
  if (!prefersReducedMotion) explode()

  let mx = -999
  let my = -999
  let mActive = false
  const toCanvas = (e: PointerEvent) => {
    const r = cv.getBoundingClientRect()
    return [((e.clientX - r.left) * W) / r.width, ((e.clientY - r.top) * H) / r.height]
  }
  const onMove = (e: PointerEvent) => {
    const p = toCanvas(e)
    mx = p[0]
    my = p[1]
    mActive = true
  }
  const onLeave = () => {
    mActive = false
    mx = my = -999
  }
  const scatter = () => {
    for (let j = 0; j < N; j++) {
      const px = X[j] + dx[j]
      const py = Y[j] + dy[j]
      const pz = Z[j] + dz[j]
      const l = Math.hypot(px, py, pz) || 1
      const f = 0.12 + R() * 0.35
      vx[j] += (px / l) * f + (R() - 0.5) * 0.12
      vy[j] += (py / l) * f + (R() - 0.5) * 0.12
      vz[j] += (pz / l) * f + (R() - 0.5) * 0.12
    }
  }
  cv.addEventListener('pointermove', onMove, { passive: true })
  cv.addEventListener('pointerleave', onLeave)
  cv.addEventListener('click', scatter)

  let visible = false
  let started = false
  const io = new IntersectionObserver(([e]) => {
    visible = e.isIntersecting
    if (visible && !started) {
      started = true
      if (!prefersReducedMotion) explode() // re-scatter at the moment it first comes into view
    }
  })
  io.observe(cv)

  // Transparent canvas: each pixel keeps the brightest particle colour that touched it, and its
  // opacity builds up with overlap, so a lone particle is a clear dot and dense areas glow.
  const plot = (x: number, y: number, r: number, g: number, b: number, w: number) => {
    if (x < 0 || y < 0 || x >= W - 1 || y >= H - 1) return
    const o = (y * W + x) * 4
    if (r > buf[o]) buf[o] = r
    if (g > buf[o + 1]) buf[o + 1] = g
    if (b > buf[o + 2]) buf[o + 2] = b
    buf[o + 3] += w * 255 * 1.25
  }

  let raf = 0
  const t0 = performance.now()
  let prev = t0
  const frame = (now: number) => {
    raf = requestAnimationFrame(frame)
    if (!visible) {
      prev = now
      return
    }
    const t = (now - t0) / 1000
    // Physics is written per 60 fps frame; scale it so motion takes the same time at any frame rate.
    const step = Math.min(4, Math.max(0.5, ((now - prev) / 1000) * 60))
    prev = now
    const damp = Math.pow(0.9, step)
    // Keep the headphone roughly front-on so the wordmark inside it stays framed by the band.
    const yaw = prefersReducedMotion ? 0 : 0.2 * Math.sin(t * 0.5)
    const pitch = 0.04 + (mActive ? (my / H - 0.5) * 0.12 : 0)
    const cy_ = Math.cos(yaw)
    const sy_ = Math.sin(yaw)
    const cp = Math.cos(pitch)
    const sp = Math.sin(pitch)
    buf.fill(0)

    for (let j = 0; j < N; j++) {
      const wx = X[j] + dx[j]
      const wy = Y[j] + dy[j]
      const wz = Z[j] + dz[j]
      const x1 = wx * cy_ + wz * sy_
      const z1 = -wx * sy_ + wz * cy_
      const y2 = wy * cp - z1 * sp
      const z2 = wy * sp + z1 * cp
      const sc = F / (F + z2)
      const sx = W / 2 + x1 * sc * U
      const sy = H / 2 - (y2 + 0.05) * sc * U

      if (mActive) {
        const ex = sx - mx
        const ey = sy - my
        const d2 = ex * ex + ey * ey
        if (d2 < 14000) {
          const dd = Math.sqrt(d2) + 0.001
          let f = 1 - dd / 118
          f = f * f * 0.06
          const ux = ex / dd
          const uy = -ey / dd
          f *= step
          vx[j] += cy_ * ux * f
          vz[j] += sy_ * ux * f
          vy[j] += uy * f
          vz[j] += (R() - 0.5) * f * 0.6
        }
      }
      vx[j] += -0.045 * dx[j] * step
      vy[j] += -0.045 * dy[j] * step
      vz[j] += -0.045 * dz[j] * step
      vx[j] *= damp
      vy[j] *= damp
      vz[j] *= damp
      dx[j] += vx[j] * step
      dy[j] += vy[j] * step
      dz[j] += vz[j] * step

      const depth = 0.38 + 0.62 * Math.max(0, Math.min(1, 1 - (z2 + 1.7) / 3.4))
      const tw = 0.8 + 0.2 * Math.sin(t * 2.2 + j * 0.37)
      const k = depth * tw * 0.55 * CW[j]
      const ix = sx | 0
      const iy = sy | 0
      const r = CR[j] * 255
      const g = CG[j] * 255
      const b = CB[j] * 255
      plot(ix, iy, r, g, b, k)
      plot(ix + 1, iy, r, g, b, k * 0.6)
      plot(ix, iy + 1, r, g, b, k * 0.6)
      plot(ix + 1, iy + 1, r, g, b, k * 0.35)
    }
    ctx.putImageData(img, 0, 0)
    if (mActive) {
      const gr = ctx.createRadialGradient(mx, my, 0, mx, my, 130)
      gr.addColorStop(0, 'rgba(90,155,239,0.16)')
      gr.addColorStop(1, 'rgba(90,155,239,0)')
      ctx.fillStyle = gr
      ctx.fillRect(mx - 130, my - 130, 260, 260)
    }
  }
  raf = requestAnimationFrame(frame)

  return () => {
    cancelAnimationFrame(raf)
    io.disconnect()
    cv.removeEventListener('pointermove', onMove)
    cv.removeEventListener('pointerleave', onLeave)
    cv.removeEventListener('click', scatter)
  }
}

// Samples particles from a product cutout (transparent PNG/WebP): the silhouette and strong edges get
// more particles, so any product reads clearly. Depth comes from brightness, which gives gentle parallax.
async function imagePoints(src: string, count = 11000): Promise<Pts> {
  const img = new Image()
  img.src = src
  await img.decode()
  const S = 240
  const c = document.createElement('canvas')
  c.width = S
  c.height = S
  const g = c.getContext('2d', { willReadFrequently: true })!
  const k = Math.min(S / img.naturalWidth, S / img.naturalHeight)
  g.drawImage(img, (S - img.naturalWidth * k) / 2, (S - img.naturalHeight * k) / 2, img.naturalWidth * k, img.naturalHeight * k)
  const d = g.getImageData(0, 0, S, S).data
  const A = (x: number, y: number) => (x < 0 || y < 0 || x >= S || y >= S ? 0 : d[(y * S + x) * 4 + 3] / 255)
  const L = (x: number, y: number) => {
    if (x < 0 || y < 0 || x >= S || y >= S) return 0
    const o = (y * S + x) * 4
    return ((d[o] * 0.299 + d[o + 1] * 0.587 + d[o + 2] * 0.114) / 255) * (d[o + 3] / 255)
  }
  const w = new Float32Array(S * S)
  let total = 0
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      if (A(x, y) < 0.3) continue
      const ea = Math.abs(A(x + 1, y) - A(x - 1, y)) + Math.abs(A(x, y + 1) - A(x, y - 1))
      const el = Math.abs(L(x + 1, y) - L(x - 1, y)) + Math.abs(L(x, y + 1) - L(x, y - 1))
      const v = 0.2 + 2.2 * ea + 1.6 * el
      w[y * S + x] = v
      total += v
    }
  const cdf = new Float32Array(S * S)
  let run = 0
  for (let i = 0; i < S * S; i++) {
    run += w[i]
    cdf[i] = run
  }
  const P: Pts = { x: [], y: [], z: [], r: [], g: [], b: [], w: [] }
  for (let n = 0; n < count; n++) {
    const t = Math.random() * total
    let lo = 0
    let hi = S * S - 1
    while (lo < hi) {
      const mid = (lo + hi) >> 1
      if (cdf[mid] < t) lo = mid + 1
      else hi = mid
    }
    const px = lo % S
    const py = (lo / S) | 0
    const lum = L(px, py)
    const edge = Math.min(1, (w[lo] - 0.2) / 1.6)
    const mix = Math.min(1, edge * 0.9 + lum * 0.7)
    const br = 0.6 + 0.4 * mix
    P.x.push(((px + Math.random()) / S - 0.5) * 2.5)
    P.y.push(-((py + Math.random()) / S - 0.5) * 2.5 - 0.05)
    P.z.push((lum - 0.4) * 0.5 + (Math.random() - 0.5) * 0.16)
    P.r.push((0.35 + 0.57 * mix) * br)
    P.g.push((0.62 + 0.33 * mix) * br)
    P.b.push((0.95 + 0.05 * mix) * br)
    P.w.push(0.9 + 0.5 * edge)
  }
  return P
}

export type ParticleSource = { kind: 'headphone' } | { kind: 'image'; src: string }

export function ParticleField({ source }: { source: ParticleSource }) {
  const canvas = useRef<HTMLCanvasElement>(null)
  const key = source.kind === 'image' ? source.src : 'headphone'

  useEffect(() => {
    let cancelled = false
    let stop = () => {}
    const make = source.kind === 'image' ? imagePoints(source.src) : Promise.resolve(buildHeadphonePoints())
    make
      .then((P) => {
        if (!cancelled && canvas.current) stop = start(canvas.current, P)
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
      stop()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  return <canvas ref={canvas} className="phones__canvas" aria-hidden="true" />
}
