import { site } from '../config/site'
import { NoteWord } from './NoteWord'
import { ParticleField, type ParticleSource } from './ParticleField'

export function Footer() {
  const { footer, brand } = site
  const source: ParticleSource =
    footer.particles === 'image' ? { kind: 'image', src: site.assets.cutout } : { kind: 'headphone' }

  return (
    <footer className="footer" aria-label="Site footer">
      {/* The wordmark is drawn on a canvas so the cursor can shake music notes off its letters;
          the particle product draws over it. */}
      <div className="footer__stage">
        <p className="sr-only">{footer.wordLines.join(' ')}</p>
        <NoteWord />
        {footer.particles !== 'none' && site.effects.footerParticles && <ParticleField source={source} />}
      </div>
      <p className="footer__hint u">{footer.hint}</p>

      <div className="footer__cols">
        <div className="footer__brand">
          <p className="footer__tag u">{brand.tagline}</p>
          <p className="footer__blurb">{brand.blurb}</p>
        </div>
        {footer.columns.map((col) => (
          <nav key={col.title} aria-label={`Footer ${col.title.toLowerCase()}`}>
            <h3 className="footer__h u">{col.title}</h3>
            <ul role="list">
              {col.links.map((l) => (
                <li key={l.label}>
                  <a href={l.href}>{l.label}</a>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>

      <div className="footer__base u">
        <span>
          © {footer.year} {brand.name}
        </span>
        <span>{footer.credit}</span>
      </div>
    </footer>
  )
}
