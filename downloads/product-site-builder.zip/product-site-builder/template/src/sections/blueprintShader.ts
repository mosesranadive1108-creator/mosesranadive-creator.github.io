// Blueprint look for the hero assembly: edge-traced line work, section hatching and a
// drafting grid, mixed with the real image by uReal (0..1).
export const BLUEPRINT_VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`

export const BLUEPRINT_FRAG = `
precision highp float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform float uReal;   // 0 = blueprint, 1 = real product
uniform float uTime;

float lum(vec2 uv) {
  vec4 c = texture2D(uTex, uv);
  return dot(c.rgb, vec3(0.299, 0.587, 0.114)) * c.a;
}
float alphaAt(vec2 uv) { return texture2D(uTex, uv).a; }

// Sobel magnitude of a scalar field.
float sobelLum(vec2 uv, vec2 d) {
  float tl = lum(uv + vec2(-d.x,  d.y)), t = lum(uv + vec2(0.0,  d.y)), tr = lum(uv + vec2(d.x,  d.y));
  float l  = lum(uv + vec2(-d.x, 0.0)),                                   r  = lum(uv + vec2(d.x, 0.0));
  float bl = lum(uv + vec2(-d.x, -d.y)), b = lum(uv + vec2(0.0, -d.y)), br = lum(uv + vec2(d.x, -d.y));
  float gx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl);
  float gy = (tl + 2.0 * t + tr) - (bl + 2.0 * b + br);
  return length(vec2(gx, gy));
}
float sobelAlpha(vec2 uv, vec2 d) {
  float tl = alphaAt(uv + vec2(-d.x,  d.y)), t = alphaAt(uv + vec2(0.0,  d.y)), tr = alphaAt(uv + vec2(d.x,  d.y));
  float l  = alphaAt(uv + vec2(-d.x, 0.0)),                                     r  = alphaAt(uv + vec2(d.x, 0.0));
  float bl = alphaAt(uv + vec2(-d.x, -d.y)), b = alphaAt(uv + vec2(0.0, -d.y)), br = alphaAt(uv + vec2(d.x, -d.y));
  float gx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl);
  float gy = (tl + 2.0 * t + tr) - (bl + 2.0 * b + br);
  return length(vec2(gx, gy));
}

void main() {
  vec2 uv = vec2(vUv.x, 1.0 - vUv.y);
  vec4 real = texture2D(uTex, uv);
  vec2 d = uTexel * 1.25;

  // Technical line work: silhouette from alpha edges, internal detail from luminance edges.
  float outline = smoothstep(0.25, 0.9, sobelAlpha(uv, d));
  float detail = smoothstep(0.05, 0.22, sobelLum(uv, d));
  float lines = clamp(outline + detail * 0.85, 0.0, 1.0);

  // Section hatching inside the parts, and a faint blueprint fill.
  float hatch = step(fract((gl_FragCoord.x + gl_FragCoord.y) / 7.0), 0.16) * 0.22;
  float body = real.a;

  // Drafting grid behind the parts: minor and major lines, faded to the edges of the stage.
  vec2 g = abs(fract(vUv * 24.0) - 0.5);
  vec2 G = abs(fract(vUv * 6.0) - 0.5);
  vec2 fw = fwidth(vUv * 24.0);
  vec2 FW = fwidth(vUv * 6.0);
  float minor = max(smoothstep(0.5 - fw.x * 1.2, 0.5, g.x), smoothstep(0.5 - fw.y * 1.2, 0.5, g.y));
  float major = max(smoothstep(0.5 - FW.x * 1.6, 0.5, G.x), smoothstep(0.5 - FW.y * 1.6, 0.5, G.y));
  float vignette = 1.0 - smoothstep(0.25, 0.72, length(vUv - 0.5));
  float grid = (minor * 0.10 + major * 0.22) * vignette;

  // A scanning highlight sweeps down the drawing.
  float scan = exp(-pow((uv.y - fract(uTime * 0.12)) * 18.0, 2.0)) * 0.35;

  vec3 lineCol = vec3(0.80, 0.91, 1.0);
  vec3 inkCol = vec3(0.27, 0.52, 0.95);
  vec3 bpRgb = lineCol * lines * (1.0 + scan) + inkCol * (body * (0.10 + hatch)) + inkCol * grid;
  float bpA = clamp(lines * 0.95 + body * (0.10 + hatch) + grid, 0.0, 1.0);

  // Premultiplied output: blueprint dissolves into the real frame.
  vec4 bp = vec4(bpRgb, bpA);
  vec4 photo = vec4(real.rgb * real.a, real.a);
  gl_FragColor = mix(bp, photo, uReal);
}`
