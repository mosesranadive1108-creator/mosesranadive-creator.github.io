import { useEffect, useRef } from 'react'
import { prefersReducedMotion } from '../anim/state'
import { site } from '../config/site'

// "MOZIT ONE" drawn on a canvas so its letter shapes are known exactly. Wherever the cursor (and
// its light trail) crosses a letter, colourful music notes float up off the word, with a short
// flare of coloured light. It sits behind the particle headphone; pointer events come from the
// parent stage.
const W = 1020
const H = 630
const MAX_NOTES = 140
const PALETTE = site.theme.noteColors
const SPRITE = 64

type Note = { x: number; y: number; vx: number; vy: number; rot: number; vr: number; life: number; max: number; size: number; sprite: number; phase: number }
type Flare = { x: number; y: number; life: number; color: string }

// Pre-render each note shape in each colour (with a glow) into its own small canvas.
function buildSprites(): HTMLCanvasElement[] {
  const shapes: ((c: CanvasRenderingContext2D) => void)[] = [
    // eighth note
    (c) => {
      c.beginPath()
      c.ellipse(24, 47, 9.5, 6.8, -0.38, 0, Math.PI * 2)
      c.fill()
      c.beginPath()
      c.moveTo(31, 45)
      c.lineTo(31, 12)
      c.stroke()
      c.beginPath()
      c.moveTo(31, 12)
      c.bezierCurveTo(37, 22, 49, 25, 44, 40)
      c.stroke()
    },
    // beamed pair
    (c) => {
      c.beginPath()
      c.ellipse(17, 50, 9, 6.5, -0.38, 0, Math.PI * 2)
      c.fill()
      c.beginPath()
      c.ellipse(41, 44, 9, 6.5, -0.38, 0, Math.PI * 2)
      c.fill()
      c.beginPath()
      c.moveTo(24, 48)
      c.lineTo(24, 14)
      c.moveTo(48, 42)
      c.lineTo(48, 8)
      c.stroke()
      c.beginPath()
      c.moveTo(24, 12)
      c.lineTo(48, 5)
      c.lineTo(48, 14)
      c.lineTo(24, 21)
      c.closePath()
      c.fill()
    },
    // quarter note
    (c) => {
      c.beginPath()
      c.ellipse(26, 46, 10, 7.2, -0.38, 0, Math.PI * 2)
      c.fill()
      c.beginPath()
      c.moveTo(34, 44)
      c.lineTo(34, 10)
      c.stroke()
    },
  ]
  const out: HTMLCanvasElement[] = []
  for (const color of PALETTE) {
    for (const shape of shapes) {
      const cv = document.createElement('canvas')
      cv.width = SPRITE
      cv.height = SPRITE
      const c = cv.getContext('2d')!
      c.fillStyle = color
      c.strokeStyle = color
      c.lineWidth = 3.6
      c.lineCap = 'round'
      c.lineJoin = 'round'
      c.shadowColor = color
      c.shadowBlur = 9
      shape(c)
      c.shadowBlur = 0
      shape(c) // second pass keeps the core crisp over the glow
      out.push(cv)
    }
  }
  return out
}

export function NoteWord() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const cv = canvas.current!
    const ctx = cv.getContext('2d')!
    cv.width = W
    cv.height = H
    const host = cv.parentElement!

    // --- the word, its glyph mask for hit-testing, and the pre-rendered glowing word ---
    const word = document.createElement('canvas')
    word.width = W
    word.height = H
    let mask = new Uint8Array(W * H)

    const buildWord = () => {
      const fs = (site.footer.wordSizeCqw / 100) * W
      const font = `700 ${fs}px "${site.fonts.heading}", "Arial Narrow", sans-serif`
      const lines = site.footer.wordLines
      const draw = (c: CanvasRenderingContext2D) => {
        c.font = font
        c.textAlign = 'center'
        c.textBaseline = 'alphabetic'
        if ('letterSpacing' in c) (c as unknown as { letterSpacing: string }).letterSpacing = `${0.015 * fs}px`
        const cap = c.measureText('M').actualBoundingBoxAscent
        const gap = 0.84 * fs
        const cy = (site.footer.wordTop / 100) * H
        lines.forEach((t, i) => c.fillText(t, W / 2, cy + (i - (lines.length - 1) / 2) * gap + cap / 2))
      }
      const m = document.createElement('canvas')
      m.width = W
      m.height = H
      const mc = m.getContext('2d', { willReadFrequently: true })!
      mc.fillStyle = '#fff'
      draw(mc)
      const data = mc.getImageData(0, 0, W, H).data
      const next = new Uint8Array(W * H)
      for (let i = 0; i < W * H; i++) next[i] = data[i * 4 + 3]
      mask = next
      const wc = word.getContext('2d')!
      wc.clearRect(0, 0, W, H)
      wc.fillStyle = '#eef3fa'
      wc.shadowColor = 'rgba(90,155,239,0.38)'
      wc.shadowBlur = 40
      draw(wc)
    }
    buildWord()
    let alive = true
    document.fonts?.load?.(`700 100px "${site.fonts.heading}"`).then(() => (alive ? buildWord() : undefined)).catch(() => undefined)

    // --- notes ---
    const sprites = buildSprites()
    const notes: Note[] = []
    const flares: Flare[] = []
    const R = Math.random
    let lx = 0
    let ly = 0
    let have = false

    const emit = (x: number, y: number, dirx: number, diry: number) => {
      if (notes.length >= MAX_NOTES) notes.shift()
      const max = 1.3 + R() * 1.1
      notes.push({
        x,
        y,
        vx: -dirx * (0.6 + R() * 1.4) + (R() - 0.5) * 3.2,
        vy: -(2 + R() * 3.4) - diry * 0.8,
        rot: (R() - 0.5) * 0.8,
        vr: (R() - 0.5) * 0.06,
        life: max,
        max,
        size: 0.55 + R() * 0.55,
        sprite: (R() * sprites.length) | 0,
        phase: R() * Math.PI * 2,
      })
    }

    const onMove = (e: PointerEvent) => {
      if (prefersReducedMotion || !site.effects.noteWordmark) return
      const r = cv.getBoundingClientRect()
      const x = ((e.clientX - r.left) * W) / r.width
      const y = ((e.clientY - r.top) * H) / r.height
      if (!have) {
        lx = x
        ly = y
        have = true
      }
      const dx = x - lx
      const dy = y - ly
      const dist = Math.hypot(dx, dy)
      const dirx = dist > 0.001 ? dx / dist : 0
      const diry = dist > 0.001 ? dy / dist : 0
      // Walk along the path since the last event so fast movement doesn't skip letters.
      const steps = Math.min(40, Math.max(1, Math.ceil(dist / 7)))
      for (let s = 1; s <= steps; s++) {
        const px = lx + (dx * s) / steps
        const py = ly + (dy * s) / steps
        const ix = px | 0
        const iy = py | 0
        if (ix >= 0 && iy >= 0 && ix < W && iy < H && mask[iy * W + ix] > 128) {
          if (R() < 0.3) emit(px, py, dirx, diry)
          if (flares.length < 30 && R() < 0.3) flares.push({ x: px, y: py, life: 0.5, color: PALETTE[(R() * PALETTE.length) | 0] })
        }
      }
      lx = x
      ly = y
    }
    const onLeave = () => (have = false)
    host.addEventListener('pointermove', onMove, { passive: true })
    host.addEventListener('pointerleave', onLeave)

    let visible = false
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting))
    io.observe(cv)

    let raf = 0
    let prev = performance.now()
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame)
      if (!visible) {
        prev = now
        return
      }
      const dt = Math.min(0.05, (now - prev) / 1000)
      prev = now
      const step = Math.max(0.5, dt * 60)

      ctx.globalCompositeOperation = 'source-over'
      ctx.globalAlpha = 1
      ctx.clearRect(0, 0, W, H)
      ctx.drawImage(word, 0, 0)

      // Coloured flares where the cursor touched the letters.
      ctx.globalCompositeOperation = 'lighter'
      for (let i = flares.length - 1; i >= 0; i--) {
        const f = flares[i]
        f.life -= dt
        if (f.life <= 0) {
          flares.splice(i, 1)
          continue
        }
        const a = Math.round((f.life / 0.5) * 70).toString(16).padStart(2, '0')
        const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, 46)
        g.addColorStop(0, `${f.color}${a}`)
        g.addColorStop(1, `${f.color}00`)
        ctx.fillStyle = g
        ctx.fillRect(f.x - 46, f.y - 46, 92, 92)
      }
      ctx.globalCompositeOperation = 'source-over'

      // Notes: rise, sway side to side, spin gently, pop in and fade out.
      for (let i = notes.length - 1; i >= 0; i--) {
        const n = notes[i]
        n.life -= dt
        if (n.life <= 0) {
          notes.splice(i, 1)
          continue
        }
        const age = n.max - n.life
        n.vx *= Math.pow(0.985, step)
        n.vy = n.vy * Math.pow(0.985, step) - 0.03 * step
        n.x += (n.vx + Math.sin(age * 3.2 + n.phase) * 0.9) * step
        n.y += n.vy * step
        n.rot += n.vr * step
        const k = n.life / n.max
        const pop = Math.min(1, age / 0.18)
        const s = n.size * (0.4 + 0.6 * pop) * (k < 0.3 ? 0.6 + (k / 0.3) * 0.4 : 1)
        ctx.globalAlpha = Math.min(1, k * 2.2)
        ctx.save()
        ctx.translate(n.x, n.y)
        ctx.rotate(n.rot + Math.sin(age * 2.4 + n.phase) * 0.25)
        ctx.scale(s, s)
        ctx.drawImage(sprites[n.sprite], -SPRITE / 2, -SPRITE / 2)
        ctx.restore()
      }
      ctx.globalAlpha = 1
    }
    raf = requestAnimationFrame(frame)

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      io.disconnect()
      host.removeEventListener('pointermove', onMove)
      host.removeEventListener('pointerleave', onLeave)
    }
  }, [])

  return <canvas ref={canvas} className="footer__spark" aria-hidden="true" />
}
