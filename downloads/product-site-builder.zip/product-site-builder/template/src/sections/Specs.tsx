import { Fragment } from 'react'
import { site } from '../config/site'
import { SpecsArt } from './SpecsArt'

export function Specs() {
  const { specs, assets } = site
  return (
    <section id="specs" className="specs" aria-labelledby="specs-title">
      <div className="specs__sticky">
        {assets.specsArt && <SpecsArt />}
        <div className="specs__copy">
          <h2 id="specs-title" className="specs__heading u">
            {specs.headingLines.map((line, i) => (
              <Fragment key={line}>
                {line}
                {i < specs.headingLines.length - 1 && <br />}
              </Fragment>
            ))}
          </h2>
          <p className="specs__body">{specs.body}</p>
        </div>
        <div className="specs__middle" />
        <ul className="specs__cards" role="list" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
          {specs.items.map((s) => (
            <li key={s.label} className="spec glass">
              <span className="spec__ghost" aria-hidden="true">
                {s.ghost}
              </span>
              <p className="spec__label u">{s.label}</p>
              <p className="spec__value u">{s.value}</p>
              <p className="spec__note">{s.note}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
