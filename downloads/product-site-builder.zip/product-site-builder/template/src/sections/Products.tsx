import { useRef } from 'react'
import { useCart } from '../cart/CartContext'
import { site } from '../config/site'

export function Products() {
  const rail = useRef<HTMLDivElement>(null)
  const { add } = useCart()
  const step = (dir: 1 | -1) => {
    const el = rail.current
    const card = el?.querySelector<HTMLElement>('.card')
    if (el && card) el.scrollBy({ left: dir * (card.offsetWidth + 18), behavior: 'smooth' })
  }

  return (
    <section id="products" className="products" aria-labelledby="products-title">
      <div className="products__head">
        <div>
          <h2 id="products-title" className="products__title u">
            {site.lineup.title}
          </h2>
          <p className="products__lede">{site.lineup.lede}</p>
        </div>
        <div className="rail__controls">
          <button className="btn btn--ghost glass rail__btn" type="button" aria-label="Previous products" onClick={() => step(-1)}>
            ←
          </button>
          <button className="btn btn--ghost glass rail__btn" type="button" aria-label="Next products" onClick={() => step(1)}>
            →
          </button>
        </div>
      </div>
      <div className="rail" ref={rail} tabIndex={0} role="region" aria-label="Products, scroll horizontally">
        {site.products.map((p) => (
          <article key={p.id} className={`card glass${p.featured ? ' card--featured' : ''}`}>
            <div className="card__media">
              {p.featured ? (
                // The 3D headphones fly to this box; on landing they fade out and this render fades in.
                <div className="card__dock" data-dock>
                  <img src={p.image} alt={p.name} width={800} height={800} data-dock-img />
                </div>
              ) : (
                <img src={p.image} alt={p.name} loading="lazy" width={800} height={800} />
              )}
            </div>
            <div className="card__body">
              <div>
                <p className="card__kicker u">{p.kicker}</p>
                <h3 className="card__name u">{p.name}</h3>
                <p className="card__desc">{p.desc}</p>
              </div>
              <div className="card__cta">
                <span className="card__price u">{p.price}</span>
                {site.effects.cart ? (
                  <button type="button" className={`btn ${p.featured ? 'btn--primary' : 'btn--ghost'}`} onClick={() => add(p)}>
                    {p.featured ? site.cart.featuredLabel : site.cart.addLabel}
                  </button>
                ) : (
                  <a className={`btn ${p.featured ? 'btn--primary' : 'btn--ghost'}`} href={p.href ?? '#products'}>
                    {p.featured ? site.cart.featuredLabel : site.cart.addLabel}
                  </a>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
