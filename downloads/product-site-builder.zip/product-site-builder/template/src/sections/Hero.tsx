import { Fragment } from 'react'
import { site } from '../config/site'
import { AssemblySequence } from './AssemblySequence'

export function Hero() {
  const { hero, brand } = site
  return (
    <section id="hero" className="hero" aria-labelledby="hero-title">
      <div className="hero__sticky">
        <div className="hero__copy">
          <p className="hero__tagline u">{brand.tagline}</p>
          <h1 id="hero-title" className="hero__title u">
            {hero.titleLines.map((line, i) => (
              <Fragment key={line}>
                {line}
                {i < hero.titleLines.length - 1 && <br />}
              </Fragment>
            ))}
          </h1>
          <p className="hero__sub">{hero.sub}</p>
          <div className="hero__actions">
            <a className="btn btn--primary" href={hero.primaryCta.href}>
              {hero.primaryCta.label}
            </a>
            <a className="btn btn--ghost glass" href={hero.secondaryCta.href}>
              {hero.secondaryCta.label}
            </a>
          </div>
        </div>

        {/* Scroll-scrubbed assembly. The 3D product takes over from the last frame in this exact box. */}
        <div className="hero__stage" data-hero-anchor>
          <AssemblySequence />
        </div>

        <p className="hero__side u">{hero.side}</p>
        <p className="hero__hint u">{hero.hint}</p>
      </div>
    </section>
  )
}
