import { useEffect, useRef } from 'react'
import { prefersReducedMotion, scroll } from '../anim/state'
import { frameUrl, site } from '../config/site'
import { BLUEPRINT_FRAG as FRAG, BLUEPRINT_VERT as VERT } from './blueprintShader'

// Transparent image sequence of the headphones assembling, scrubbed by scroll and drawn
// through a WebGL "blueprint" shader: edge-traced technical lines and hatching on a drafting
// grid, which resolves into the real product as the last parts click in. The final frame is
// a render of the 3D model in the exact hero pose, so the hand-off to 3D stays seamless.
const FRAMES = site.hero.frameCount
const src = frameUrl

export function AssemblySequence() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const c = canvas.current!
    const gl = c.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false })
    if (!gl) return
    gl.getExtension('OES_standard_derivatives')

    const sh = (type: number, source: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, source)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s))
      return s
    }
    const prog = gl.createProgram()!
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT))
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, '#extension GL_OES_standard_derivatives : enable\n' + FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)

    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(prog, 'aPos')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)

    const tex = gl.createTexture()
    gl.bindTexture(gl.TEXTURE_2D, tex)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false)

    const uTexel = gl.getUniformLocation(prog, 'uTexel')
    const uReal = gl.getUniformLocation(prog, 'uReal')
    const uTime = gl.getUniformLocation(prog, 'uTime')

    const images: HTMLImageElement[] = []
    for (let i = 0; i < FRAMES; i++) {
      const img = new Image()
      img.decoding = 'async'
      img.src = src(i)
      images.push(img)
    }

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2)
      const r = c.getBoundingClientRect()
      c.width = Math.round(r.width * dpr)
      c.height = Math.round(r.height * dpr)
      gl.viewport(0, 0, c.width, c.height)
    }
    resize()
    window.addEventListener('resize', resize)

    let uploaded = -1
    let raf = 0
    const start = performance.now()
    const draw = (now: number) => {
      const target = Math.round(scroll.assemble * (FRAMES - 1))
      // Fall back to the nearest loaded frame while the sequence streams in.
      let i = target
      while (i > 0 && !(images[i].complete && images[i].naturalWidth)) i--
      const img = images[i]
      if (img?.complete && img.naturalWidth) {
        if (i !== uploaded) {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img)
          gl.uniform2f(uTexel, 1 / img.naturalWidth, 1 / img.naturalHeight)
          uploaded = i
        }
        const p = scroll.assemble
        // Blueprint for most of the assembly, resolving into the real product at the end.
        const real = prefersReducedMotion ? 1 : Math.min(1, Math.max(0, (p - 0.6) / 0.33))
        gl.uniform1f(uReal, real * real * (3 - 2 * real))
        gl.uniform1f(uTime, (now - start) / 1000)
        gl.clearColor(0, 0, 0, 0)
        gl.clear(gl.COLOR_BUFFER_BIT)
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
      }

      // Starts 30% larger at 70% opacity and settles to exactly the stage size and full opacity
      // as the assembly completes, so the last frame lines up with the 3D model.
      const settle = 1 - Math.pow(1 - scroll.assemble, 2)
      c.style.transform = `scale(${1.3 - 0.3 * settle})`
      c.style.opacity = String((0.7 + 0.3 * settle) * (1 - scroll.handoff))
      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
      gl.deleteTexture(tex)
      gl.deleteProgram(prog)
      gl.deleteBuffer(buf)
    }
  }, [])

  return <canvas ref={canvas} className="hero__seq" aria-label={`${site.meta.title} assembling from a blueprint`} role="img" />
}
