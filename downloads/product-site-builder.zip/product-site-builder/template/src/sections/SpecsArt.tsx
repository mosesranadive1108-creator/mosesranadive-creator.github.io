import { useEffect, useRef } from 'react'
import { site } from '../config/site'
import { BLUEPRINT_FRAG, BLUEPRINT_VERT } from './blueprintShader'

// The exploded line drawing behind the specs copy, rendered through the same blueprint shader
// as the hero assembly (traced glowing lines, hatching, drafting grid and scanning highlight).
const SRC = site.assets.specsArt ?? ''

export function SpecsArt() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const c = canvas.current!
    const gl = c.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false })
    if (!gl) return
    gl.getExtension('OES_standard_derivatives')
    const sh = (type: number, source: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, source)
      gl.compileShader(s)
      return s
    }
    const prog = gl.createProgram()!
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, BLUEPRINT_VERT))
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, '#extension GL_OES_standard_derivatives : enable\n' + BLUEPRINT_FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(prog, 'aPos')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
    const tex = gl.createTexture()
    gl.bindTexture(gl.TEXTURE_2D, tex)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    const uTexel = gl.getUniformLocation(prog, 'uTexel')
    const uReal = gl.getUniformLocation(prog, 'uReal')
    const uTime = gl.getUniformLocation(prog, 'uTime')
    gl.uniform1f(uReal, 0)

    let ready = false
    const img = new Image()
    img.src = SRC
    img.onload = () => {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img)
      gl.uniform2f(uTexel, 1 / img.naturalWidth, 1 / img.naturalHeight)
      ready = true
    }

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2)
      const r = c.getBoundingClientRect()
      c.width = Math.max(1, Math.round(r.width * dpr))
      c.height = Math.max(1, Math.round(r.height * dpr))
      gl.viewport(0, 0, c.width, c.height)
    }
    resize()
    window.addEventListener('resize', resize)

    // Only animate (the scanning highlight) while it's on screen.
    let visible = false
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting))
    io.observe(c)

    let raf = 0
    const start = performance.now()
    const frame = (now: number) => {
      if (ready && visible) {
        gl.uniform1f(uTime, (now - start) / 1000)
        gl.clearColor(0, 0, 0, 0)
        gl.clear(gl.COLOR_BUFFER_BIT)
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
      }
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    return () => {
      cancelAnimationFrame(raf)
      io.disconnect()
      window.removeEventListener('resize', resize)
      gl.deleteTexture(tex)
      gl.deleteProgram(prog)
      gl.deleteBuffer(buf)
    }
  }, [])

  return <canvas ref={canvas} className="specs__art" aria-hidden="true" />
}
