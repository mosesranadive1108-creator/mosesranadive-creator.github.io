import { useEffect, useRef } from 'react'
import { ambience, pointer, prefersReducedMotion } from '../anim/state'
import { site } from '../config/site'

// Full-screen WebGL background: a slow domain-warped gradient in dark navy, blue and black,
// with a faint undulating wireframe mesh that catches the light as the gradient flows past.
const FRAG = `
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform float uGlow;
uniform vec2 uPointer;
uniform vec3 uM0, uM1, uM2, uM3, uM4, uM5; // mesh-gradient node colours (theme.mesh)

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = p * 2.02 + 17.0; a *= 0.5; }
  return v;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y;
  float t = uTime * 0.035;

  // Domain-warped flow field: two layers of noise bending a third gives silky, liquid motion.
  vec2 q = vec2(fbm(p * 1.4 + t), fbm(p * 1.4 - t + 5.2));
  vec2 r = vec2(fbm(p * 1.2 + 2.0 * q + vec2(1.7, 9.2) + t * 0.8), fbm(p * 1.2 + 2.0 * q + vec2(8.3, 2.8) - t * 0.6));
  float f = fbm(p * 1.1 + 2.2 * r + uPointer * 0.08);

  vec3 black = vec3(0.0);
  vec3 abyss = vec3(0.025, 0.028, 0.038);   // charcoal
  vec3 slate = vec3(0.075, 0.085, 0.105);   // lighter slate, the main gradient range
  vec3 navy  = vec3(0.045, 0.07, 0.14);     // navy pockets
  vec3 deep  = vec3(0.06, 0.11, 0.24);      // deep blue, used sparingly
  vec3 azure = vec3(0.12, 0.26, 0.5);       // crest highlight
  vec3 indigo = vec3(0.11, 0.08, 0.2);      // violet shade for depth

  // Mostly charcoal-to-slate with real range, with blue and violet only in pockets.
  float body = smoothstep(0.1, 0.62, f);
  vec3 col = mix(black, abyss, smoothstep(0.05, 0.4, f));
  col = mix(col, slate, body * 0.9);
  col = mix(col, navy, smoothstep(0.5, 0.8, f * (0.6 + q.x)) * 0.8);
  col = mix(col, indigo, smoothstep(0.5, 0.9, r.y) * smoothstep(0.35, 0.65, q.x) * 0.55);
  col = mix(col, deep, smoothstep(0.55, 0.9, f * length(q) * 1.4) * 0.65);
  col += azure * pow(smoothstep(0.55, 1.0, f * (0.6 + r.x)), 2.4) * 0.3;

  // Large soft light pools so the gradient reads from across the page, not just up close.
  float poolA = exp(-length(p - vec2(-0.55 + 0.1 * sin(t * 3.0), 0.35)) * 1.8);
  float poolB = exp(-length(p - vec2(0.7, -0.3 + 0.1 * cos(t * 2.6))) * 1.5);
  col += vec3(0.05, 0.07, 0.12) * poolA * 0.9 + vec3(0.08, 0.06, 0.13) * poolB * 0.7;

  // Mesh gradient: six soft colour nodes drifting on their own slow paths, blended with
  // inverse-distance weights so the colours melt into each other. Warped by the flow field
  // so it never looks like fixed blobs.
  float T = uTime * 0.09;
  vec2 pm = p + (vec2(q.x, r.y) - 0.5) * 0.45;
  vec3 mc = vec3(0.0);
  float ws = 0.0;
  vec2 mn; float mw;
  mn = vec2(-0.62 + 0.28 * sin(T * 1.1), 0.34 + 0.22 * cos(T * 0.8));        mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM0; ws += mw;
  mn = vec2(0.58 + 0.24 * cos(T * 0.9 + 1.0), 0.28 + 0.26 * sin(T * 1.2));   mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM1; ws += mw;
  mn = vec2(0.05 + 0.30 * sin(T * 0.7 + 2.0), -0.40 + 0.18 * cos(T * 1.0));  mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM2; ws += mw;
  mn = vec2(-0.55 + 0.22 * cos(T * 1.3 + 3.0), -0.32 + 0.24 * sin(T * 0.6));  mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM3; ws += mw;
  mn = vec2(0.62 + 0.20 * sin(T * 0.8 + 4.0), -0.30 + 0.22 * cos(T * 1.1 + 1.0)); mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM4; ws += mw;
  mn = vec2(0.0 + 0.35 * cos(T * 0.5 + 5.0), 0.55 + 0.12 * sin(T * 0.9));    mw = 1.0 / (dot(pm - mn, pm - mn) + 0.07); mw *= mw; mc += mw * uM5; ws += mw;
  mc /= ws;
  col = mix(col, mc, 0.68);

  // Wireframe mesh: a grid in perspective, displaced by the same flow so it ripples with it.
  vec2 g = vec2(p.x, p.y + 0.6);
  float persp = 1.0 / max(0.25, 1.15 - g.y * 0.9);
  vec2 m = vec2(g.x * persp, persp + t * 6.0) * 7.0;
  m += (vec2(f, r.y) - 0.5) * 1.6;
  vec2 cell = abs(fract(m) - 0.5);
  vec2 w = fwidth(m) * 1.1;
  float gx = 1.0 - smoothstep(0.0, w.x, cell.x - (0.5 - w.x));
  float gy = 1.0 - smoothstep(0.0, w.y, cell.y - (0.5 - w.y));
  float grid = max(1.0 - gx, 1.0 - gy);
  grid *= smoothstep(0.0, 0.2, uv.y) * (1.0 - smoothstep(0.62, 1.0, uv.y)); // fade toward edges and horizon
  float lit = 0.18 + 0.9 * smoothstep(0.4, 0.85, f);                      // lines catch the flowing light
  col += vec3(0.55, 0.62, 0.75) * grid * lit * 0.26;

  // Vignette to black and overall brightness.
  float vig = 1.0 - smoothstep(0.25, 1.25, length(p * vec2(0.85, 1.0)));
  col *= mix(0.35, 1.0, vig) * uGlow;

  // Dither to avoid banding in the dark gradients.
  col += (hash(gl_FragCoord.xy + fract(uTime)) - 0.5) / 255.0;
  gl_FragColor = vec4(col, 1.0);
}`

const VERT = `attribute vec2 a; void main() { gl_Position = vec4(a, 0.0, 1.0); }`

export function BgMotion() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const c = canvas.current!
    const gl = c.getContext('webgl', { antialias: false, alpha: false })
    if (!gl) return
    gl.getExtension('OES_standard_derivatives')
    const sh = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s))
      return s
    }
    const prog = gl.createProgram()!
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT))
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, '#extension GL_OES_standard_derivatives : enable\n' + FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(prog, 'a')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
    const uRes = gl.getUniformLocation(prog, 'uRes')
    const uTime = gl.getUniformLocation(prog, 'uTime')
    const uGlow = gl.getUniformLocation(prog, 'uGlow')
    const uPointer = gl.getUniformLocation(prog, 'uPointer')
    site.theme.mesh.slice(0, 6).forEach((hex, i) => {
      const n = parseInt(hex.replace('#', ''), 16)
      gl.uniform3f(gl.getUniformLocation(prog, `uM${i}`), ((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255)
    })

    // Soft content, so render below device resolution; the mesh lines stay smooth via fwidth.
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 1.5) * 0.75
      c.width = Math.round(window.innerWidth * dpr)
      c.height = Math.round(window.innerHeight * dpr)
      gl.viewport(0, 0, c.width, c.height)
      gl.uniform2f(uRes, c.width, c.height)
    }
    resize()
    window.addEventListener('resize', resize)

    let raf = 0
    let px = 0
    let py = 0
    const start = performance.now()
    const frame = (now: number) => {
      px += (pointer.x - px) * 0.03
      py += (pointer.y - py) * 0.03
      gl.uniform1f(uTime, prefersReducedMotion ? 20 : (now - start) / 1000)
      gl.uniform1f(uGlow, ambience.glow)
      gl.uniform2f(uPointer, px, -py)
      gl.drawArrays(gl.TRIANGLES, 0, 3)
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
      gl.deleteProgram(prog)
      gl.deleteBuffer(buf)
    }
  }, [])

  return (
    <div className="bg-motion" aria-hidden="true">
      <canvas ref={canvas} className="bg-motion__canvas" />
      <span className="bg-motion__grain" />
    </div>
  )
}
