import { site } from '../config/site'

// Logo = a mark (drawn in code, so it scales and takes the page colours) beside the wordmark.
// brand.mark: 'headphone' (band, cups and a three-bar wave), 'monogram' (first letter in a rounded
// square) or 'none'. Swap in your own SVG here if the brand has one.
export function LogoMark({ className = '' }: { className?: string }) {
  const { mark, name } = site.brand
  if (mark === 'none') return null
  if (mark === 'monogram')
    return (
      <svg className={`logo__mark ${className}`} viewBox="0 0 64 64" fill="none" aria-hidden="true">
        <rect x="6" y="6" width="52" height="52" rx="14" stroke="currentColor" strokeWidth="4" />
        <text x="32" y="45" textAnchor="middle" fontFamily="var(--font-heading)" fontWeight="700" fontSize="36" fill="currentColor">
          {name.charAt(0)}
        </text>
      </svg>
    )
  return (
    <svg className={`logo__mark ${className}`} viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <path d="M13 36V32a19 19 0 0 1 38 0v4" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
      <rect x="9" y="34" width="9" height="16" rx="4.5" fill="currentColor" />
      <rect x="46" y="34" width="9" height="16" rx="4.5" fill="currentColor" />
      <path className="logo__wave" d="M26 42v6M32 38v14M38 43v5" stroke="var(--color-sky)" strokeWidth="3.2" strokeLinecap="round" />
    </svg>
  )
}

export function Logo() {
  const { name, accentLetterIndex } = site.brand
  return (
    <a className="logo" href="#hero" aria-label={`${name} home`}>
      <LogoMark />
      <span className="logo__word u">
        {name.split('').map((ch, i) => (i === accentLetterIndex ? <span key={i} className="logo__z">{ch}</span> : ch))}
      </span>
    </a>
  )
}
