import { useEffect, useRef } from 'react'
import { prefersReducedMotion } from '../anim/state'

// Glowing light trail that follows the cursor (inspired by React Bits' GlowCursor).
// A chain of spring-followed points is turned into a tapered ribbon each frame and shaded
// with a bright core and a soft azure glow, blended over the page with `screen`.
const POINTS = 56
const HEAD_WIDTH = 46 // CSS px, full glow width at the head

const VERT = `
attribute vec2 aPos;   // px
attribute float aSide; // -1..1 across the ribbon
attribute float aT;    // 0 head .. 1 tail
uniform vec2 uRes;
varying float vSide;
varying float vT;
void main() {
  vSide = aSide;
  vT = aT;
  vec2 clip = (aPos / uRes) * 2.0 - 1.0;
  gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
}`

const FRAG = `
precision mediump float;
varying float vSide;
varying float vT;
uniform float uTime;
uniform float uEnergy;
void main() {
  float d = abs(vSide);
  float core = exp(-d * d * 28.0);
  float glow = exp(-d * d * 4.0) * 0.7;
  float tail = pow(1.0 - vT, 1.6);
  float shimmer = 0.85 + 0.15 * sin(vT * 38.0 - uTime * 9.0);
  vec3 coreCol = vec3(0.9, 0.95, 1.0);
  vec3 glowCol = vec3(0.35, 0.6, 0.94);
  vec3 col = (coreCol * core + glowCol * glow) * tail * shimmer * uEnergy;
  gl_FragColor = vec4(col, max(col.r, max(col.g, col.b)));
}`

export function CursorTrail() {
  const canvas = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (prefersReducedMotion || !window.matchMedia('(pointer: fine)').matches) return
    const c = canvas.current!
    const gl = c.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: true })
    if (!gl) return

    const sh = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      return s
    }
    const prog = gl.createProgram()!
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT))
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.ONE, gl.ONE)

    const STRIDE = 4 // x, y, side, t
    const data = new Float32Array(POINTS * 2 * STRIDE)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, data.byteLength, gl.DYNAMIC_DRAW)
    const bind = (name: string, size: number, offset: number) => {
      const loc = gl.getAttribLocation(prog, name)
      gl.enableVertexAttribArray(loc)
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, STRIDE * 4, offset * 4)
    }
    bind('aPos', 2, 0)
    bind('aSide', 1, 2)
    bind('aT', 1, 3)
    const uRes = gl.getUniformLocation(prog, 'uRes')
    const uTime = gl.getUniformLocation(prog, 'uTime')
    const uEnergy = gl.getUniformLocation(prog, 'uEnergy')

    let dpr = 1
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio, 2)
      c.width = Math.round(window.innerWidth * dpr)
      c.height = Math.round(window.innerHeight * dpr)
      gl.viewport(0, 0, c.width, c.height)
      gl.uniform2f(uRes, c.width, c.height)
    }
    resize()
    window.addEventListener('resize', resize)

    // Trail state: the head chases the pointer, each point chases the one before it.
    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 }
    const pts = Array.from({ length: POINTS }, () => ({ x: target.x, y: target.y }))
    let energy = 0
    let lastMove = 0
    const onMove = (e: PointerEvent) => {
      const now = performance.now()
      const jumped = Math.hypot(e.clientX - target.x, e.clientY - target.y) > 280
      // Entering the window, resuming after idle or a big jump: restart the trail at the cursor
      // instead of drawing a long streak from wherever it last was.
      if (!lastMove || now - lastMove > 600 || jumped) pts.forEach((p) => ((p.x = e.clientX), (p.y = e.clientY)))
      target.x = e.clientX
      target.y = e.clientY
      lastMove = now
    }
    const onLeave = () => (lastMove = 0)
    window.addEventListener('pointermove', onMove, { passive: true })
    document.addEventListener('pointerleave', onLeave)

    let raf = 0
    let prev = performance.now()
    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - prev) / 1000)
      prev = now

      const head = pts[0]
      head.x += (target.x - head.x) * (1 - Math.exp(-dt * 38))
      head.y += (target.y - head.y) * (1 - Math.exp(-dt * 38))
      for (let i = 1; i < POINTS; i++) {
        const k = 1 - Math.exp(-dt * (26 - i * 0.28))
        pts[i].x += (pts[i - 1].x - pts[i].x) * k
        pts[i].y += (pts[i - 1].y - pts[i].y) * k
      }

      // Glow while moving, fade out gently when the cursor rests or leaves.
      const active = lastMove && now - lastMove < 450 ? 1 : 0
      energy += (active - energy) * (1 - Math.exp(-dt * (active ? 10 : 2.2)))

      for (let i = 0; i < POINTS; i++) {
        const a = pts[Math.max(0, i - 1)]
        const b = pts[Math.min(POINTS - 1, i + 1)]
        let nx = -(b.y - a.y)
        let ny = b.x - a.x
        const len = Math.hypot(nx, ny) || 1
        nx /= len
        ny /= len
        const t = i / (POINTS - 1)
        const w = ((HEAD_WIDTH * dpr) / 2) * (0.35 + 0.65 * Math.pow(1 - t, 0.9))
        const px = pts[i].x * dpr
        const py = pts[i].y * dpr
        const o = i * 2 * STRIDE
        data.set([px + nx * w, py + ny * w, 1, t, px - nx * w, py - ny * w, -1, t], o)
      }

      gl.clearColor(0, 0, 0, 0)
      gl.clear(gl.COLOR_BUFFER_BIT)
      if (energy > 0.002) {
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, data)
        gl.uniform1f(uTime, now / 1000)
        gl.uniform1f(uEnergy, energy)
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, POINTS * 2)
      }
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
      window.removeEventListener('pointermove', onMove)
      document.removeEventListener('pointerleave', onLeave)
      gl.deleteProgram(prog)
      gl.deleteBuffer(buf)
    }
  }, [])

  return <canvas ref={canvas} className="cursor-trail" aria-hidden="true" />
}
