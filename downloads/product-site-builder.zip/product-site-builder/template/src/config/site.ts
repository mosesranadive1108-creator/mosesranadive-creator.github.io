import raw from '../../site.config.json'

// Typed view of site.config.json. Edit the JSON, not this file.
export type Link = { label: string; href: string }
export type Product = { id: string; kicker: string; name: string; desc: string; price: string; image?: string; featured?: boolean; href?: string }
export type Spec = { label: string; value: string; note: string; ghost: string }

export type SiteConfig = {
  effects: {
    meshBackground: boolean // animated mesh-gradient background
    cursorTrail: boolean // glowing light trail that follows the cursor
    cursorParticles: boolean // the cursor dissolves the 3D model into particles
    noteWordmark: boolean // footer wordmark sheds notes when the cursor crosses it
    footerParticles: boolean // particle product in the footer
    cart: boolean // cart button + drawer (off: product buttons become links)
  }
  brand: { name: string; slug: string; mark: 'headphone' | 'monogram' | 'none'; accentLetterIndex: number; tagline: string; blurb: string }
  meta: { title: string; description: string }
  fonts: { heading: string; body: string; googleQuery: string }
  theme: {
    colors: Record<string, string>
    ctaText: string
    heroBg: string
    darkBg: string
    mesh: string[]
    noteColors: string[]
  }
  assets: { model: string; cardImage: string; cutout: string; specsArt: string | null }
  hero: {
    titleLines: string[]
    sub: string
    primaryCta: Link
    secondaryCta: Link
    side: string
    hint: string
    framesPath: string
    frameCount: number
    restRotation: [number, number, number]
    beats: { assembled: number; handoffStart: number; handoffEnd: number }
  }
  specs: { headingLines: string[]; body: string; items: Spec[] }
  lineup: { title: string; lede: string }
  products: Product[]
  nav: Link[]
  cart: { currency: string; storageKey: string; addLabel: string; featuredLabel: string }
  footer: {
    wordLines: string[]
    wordTop: number
    wordSizeCqw: number
    particles: 'headphone' | 'image' | 'none'
    hint: string
    credit: string
    year: string
    columns: { title: string; links: Link[] }[]
  }
}

export const site = raw as unknown as SiteConfig

// Frame URL for the hero sequence, e.g. /seq/assembly/001.webp
export const frameUrl = (i: number) => `${site.hero.framesPath}${String(i + 1).padStart(3, '0')}.webp`
