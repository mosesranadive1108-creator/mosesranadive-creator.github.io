import { lazy, Suspense, useEffect } from 'react'
import { startAmbience } from './anim/ambience'
import { site } from './config/site'
import { setupScroll } from './anim/scroll'
import { Logo } from './sections/Logo'
import { setupSurfaces } from './anim/surface'
import { BgMotion } from './sections/BgMotion'
import { CursorTrail } from './sections/CursorTrail'
import { CartButton } from './cart/CartButton'
import { Footer } from './sections/Footer'
import { CartDrawer } from './cart/CartDrawer'
import { CartProvider } from './cart/CartContext'
import { Hero } from './sections/Hero'
import { Products } from './sections/Products'
import { Specs } from './sections/Specs'

// three.js is its own lazy chunk, so the page shell loads first.
const Stage = lazy(() => import('./scene/Stage').then((m) => ({ default: m.Stage })))

export default function App() {
  useEffect(() => setupScroll(), [])
  useEffect(() => setupSurfaces(), [])
  useEffect(() => startAmbience(), [])

  return (
    <CartProvider>
      <header className="nav">
        <Logo />
        <div className="nav__right">
          <nav aria-label="Main">
            <ul className="nav__links u">
              {site.nav.map((l, i) => (
                <li key={l.href}>
                  <a href={l.href} aria-current={i === 0 ? 'true' : undefined}>
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          {site.effects.cart && <CartButton />}
        </div>
      </header>
      {site.effects.meshBackground && <BgMotion />}
      <Suspense fallback={null}>
        <Stage />
      </Suspense>
      <main className="content">
        <Hero />
        <Specs />
        <Products />
      </main>
      {site.effects.cursorTrail && <CursorTrail />}
      {site.effects.cart && <CartDrawer />}
      <Footer />
    </CartProvider>
  )
}
