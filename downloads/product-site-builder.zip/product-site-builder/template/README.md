# Product scroll site (template)

A scroll-choreographed product site: pinned hero where the product assembles from a blueprint, a spec
section, a lineup rail, a cart, and a footer with a particle product and a wordmark that sheds music
notes. Everything brand-specific lives in **`site.config.json`**.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build
```

## What to edit
| File | What |
|---|---|
| `site.config.json` | Brand, copy, products, specs, palette, fonts, effect switches, asset paths, hero timing |
| `public/…` | The generated assets (see `public/ASSETS.md`) |
| `src/styles/app.css` | Layout and component styles (colours come from the theme variables) |
| `src/sections/blueprintShader.ts` | The blueprint look for the hero and spec drawing |
| `src/sections/BgMotion.tsx` | The animated mesh-gradient background (colours come from `theme.mesh`) |

## 3D product
The product is a real GLB rendered with react-three-fiber (`src/scene/*`): it takes over from the hero
sequence's last frame, rises, turns toward the cursor, flies into its card, and can dissolve into
particles under the cursor. three.js is its own lazy chunk. It requires a single-mesh model; if a
product can't be made into a good 3D model, the build workflow stops and asks the user what to do.

## Dev aids (dev server only)
`window.__lenis.scrollTo(px, {immediate:true})` jumps the scroll; `window.__scroll` shows scroll progress;
`window.__snapshot(selector, px)` renders the model to a PNG at the box of an element, used to bake
the card image so the 3D→card hand-off is pixel-identical.
