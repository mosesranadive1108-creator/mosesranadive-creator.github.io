import react from '@vitejs/plugin-react'
import { readFileSync } from 'node:fs'
import { defineConfig, type Plugin } from 'vite'

// Fills the %TITLE%, %DESCRIPTION% and %FONTS_QUERY% placeholders in index.html from site.config.json.
function siteHtml(): Plugin {
  return {
    name: 'site-config-html',
    transformIndexHtml(html) {
      const cfg = JSON.parse(readFileSync(new URL('./site.config.json', import.meta.url), 'utf8'))
      return html
        .replace('%TITLE%', cfg.meta.title)
        .replace('%DESCRIPTION%', cfg.meta.description)
        .replace('%FONTS_QUERY%', cfg.fonts.googleQuery)
    },
  }
}

export default defineConfig({
  plugins: [react(), siteHtml()],
})
