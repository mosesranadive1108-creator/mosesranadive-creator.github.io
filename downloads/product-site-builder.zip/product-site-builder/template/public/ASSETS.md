# Asset slots

The site expects these files. The `product-site-assets` skill generates them; paths are set in `site.config.json`.

| Path | What | Spec |
|---|---|---|
| `models/product.glb` | 3D model | Single mesh, Draco + WebP textures, under 3 MB |
| `seq/assembly/001.webp … NNN.webp` | Hero assembly frames, transparent | Square, 640–960 px, `hero.frameCount` files, last frame = the product at its rest pose |
| `img/hero-product.webp` | Featured card image: a render of the model at its card pose, baked from the running site | Square, transparent, ~1000 px |
| (cutout) `assets.cutout`, default `seq/assembly/096.webp` | The product's rest pose; the footer's image-sampled particles use it | Transparent, square |
| `img/acc-1.webp … acc-N.webp` | Other product cards | Square, ~900 px, matching dark studio background |
| `img/specs-exploded.webp` | Optional line drawing behind the specs copy (set `assets.specsArt` to `null` to drop it) | Transparent, ~1350 px |
| `favicon.svg` | Browser tab icon | Regenerate from the logo mark |
