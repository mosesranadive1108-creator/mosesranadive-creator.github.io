---
name: product-site-qa
description: Verifies a site built from the product-site template before handoff - validator script, type-check and build, browser-pane screenshots at every scroll beat on desktop and mobile, console errors, real click and hover tests, cart flow, reduced-motion, contrast and performance budget. Used by product-site-builder (phase 6); also use whenever a scroll-animated product site needs a final check, or when something "looks off" and needs systematic diagnosis.
---

# Product site QA

A site is not done until every blocking item below has been **seen passing**. Report only what you observed, with the evidence (the screenshot, the console output, the command result). If something cannot be verified (for example no browser pane), say so plainly and do not claim a pass.

Fix every blocking failure, re-run the whole section it belongs to, and log the result in `BUILD_LOG.md`.

## 1. Static checks (blocking)
```bash
node <skills>/product-site-builder/scripts/check-site.mjs <project> --placeholder "<template brand, e.g. MOZIT>"
cd <project> && npx tsc -b && npm run build
```
Must show: all config fields, every asset file present, frame count equals `hero.frameCount`, contrast pairs at or above 4.5, no leftover placeholder brand text, TypeScript clean, build succeeds. Also confirm the model is under 3 MB, the sequence is about 6 MB or less, and the JS main chunk is reasonable.

## 2. Visual walk-through (blocking), desktop
Start the dev server and open it in the browser pane (use a fresh `?r=<n>` query for each reload). The preview may run slowly (about 3 fps): after each jump wait several seconds before judging motion. Use `window.__lenis.scrollTo(px, {immediate: true})` (dev handle) to jump, then capture.

| Scroll position | Must look like |
|---|---|
| 0 | Hero copy left, centred vertically; exploded blueprint on the right at 70% opacity, 30% larger; CTA colour correct |
| about 0.5 viewport | Parts mid-assembly, still blueprint |
| about 0.9 | Turning real; assembled |
| about 1.05 | 3D product in the same spot and pose as the last frame: **no jump, no double image** |
| about 1.6 | Product centred, rising; hero text gone; page darker |
| specs section | Copy, glass cards with ghost numerals, drawing behind the copy (if enabled); product tilts toward the cursor |
| lineup | Cards equal size, one-line title and lede, prices large, rail scrolls sideways |
| flight and landing | Product lands in its card; the 3D model and the card image swap invisibly; scrolling back up replays it |
| footer | Particle product assembles on first view; wordmark inside it; notes shed when the cursor crosses the letters |

Scroll **backwards** through the whole page once. Use a real wheel scroll at least once (not only jumps).

## 3. Interaction tests (blocking)
- Real mouse **click** (not a scripted `.click()`) on: hero CTA, a product card button, the cart icon, a nav link, the rail arrows. If a real click does nothing, check what is on top: `document.elementFromPoint(x, y)`.
- Hover: glass highlight follows the cursor; cursor trail appears; 3D hover dissolve works and recovers.
- Cart: add two products, change quantity, remove one, close with Escape, reload (cart persists), badge bounces only on add, empty state reads well.
- Keyboard: Tab reaches every control with a visible focus ring; Escape closes the cart.

## 4. Console and network (blocking)
Read the browser console **unfiltered** (a pattern filter hides shader compile errors). Zero errors on load and during the whole walk-through. Stale HMR messages after file deletions are not real errors: reload on a fresh query and re-read. No failed requests for assets.

## 5. Responsive and accessibility
- Mobile preset (375×812): hero copy at the top, product below, nothing overflows horizontally, cards at about 78% width, cart drawer fits, footer stacks. Reset the viewport to desktop afterwards.
- Reduced motion (emulate the preference or reload with it on): no scrubbing blueprint effect, sequence shows the real product, effects off, still usable.
- Headings are real headings; images have alt text or are `aria-hidden`; icon buttons have labels; the 3D layer is `aria-hidden`.
- Contrast was checked in step 1; also eyeball text over the brightest part of the background.

## 6. Performance (advisory)
No runaway animation off screen (loops pause when not visible); no layout shift on load; fonts load with `display=swap`. If frames drop on a mid-range laptop, lower background resolution or particle count first.

## 7. Report format
```
QA result: PASS / FAIL (n blocking)
1 Static checks: <result>
2 Walk-through: <what was seen at each position; screenshots taken>
3 Interaction: <what was clicked and what happened>
4 Console: <errors found / none>
5 Responsive and accessibility: <result>
6 Performance: <notes>
Not verified: <anything you could not check, and why>
```
Never mark PASS with an unverified blocking item.
